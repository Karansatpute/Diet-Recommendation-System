<?php
// Start session
session_start();

// Assuming you have a database connection established already
// Ensure to include necessary database connection code

// Check if the user is logged in
if (!isset($_SESSION["username"])) {
    // If the user is not logged in, send an error response
    echo json_encode(array("error" => "User not logged in"));
    exit;
}

// Fetch the user's username from the session
$username = $_SESSION["username"];

// Fetch the user's calorie count from the database
$query = "SELECT calorie_count FROM user_calories WHERE username = ? ORDER BY created_at DESC LIMIT 1";
$stmt = $pdo->prepare($query);
$stmt->execute([$username]);
$userData = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the user's data is found in the database
if ($userData) {
    // Extract calorie count from fetched data
    $calorieCount = (float)$userData['calorie_count'];
    
    // Store the calorie count in a session variable
    $_SESSION['calorie_count'] = $calorieCount;
}