<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Food Calorie Detection & Diet Recommendation</title>
  <style>
    body {
      background-color: #f9f9f9;
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
    }

    header {
      background-color: #e0eddc;
      color: #fff;
      text-align: center;
      padding: 20px;
      margin-bottom: 20px;
    }

    main {
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    h1, h2 {
      color: #25a000;
    }

    section {
      margin-bottom: 30px;
    }

    footer {
      text-align: center;
      color: #666;
      margin-top: 20px;
    }

    footer p {
      margin: 10px 0;
    }
  </style>
</head>
<body>
  <header>
    <h1>About us</h1>
  </header>

  <main>
    <section>
      <h2>Who We Are</h2>
      <p>Welcome to Ntri-Track ! We are dedicated to helping individuals achieve their health and fitness goals by providing accurate information about the nutritional content of various foods and offering personalized diet recommendations.</p>
      <p>Our team consists of nutritionists, dietitians, and software engineers passionate about health and technology.</p>
    </section>

    <section>
        <h2>Our Vision</h2>
        <p>We envision a world where everyone has access to personalized nutrition information and tools to optimize their health and well-being. Through continuous innovation and collaboration with health professionals, we strive to make our platform the leading resource for food calorie detection and diet recommendation.</p>
      </section>
      
    <section>
      <h2>Our Mission</h2>
      <p>Our mission is to empower people to make informed decisions about their dietary choices and lead healthier lives. We leverage advanced technology, including machine learning algorithms, to analyze food items and provide users with detailed calorie information, enabling them to make healthier choices tailored to their individual needs and preferences.</p>
    </section>

  </main>

  <footer>
    <p>&copy; 2024 Food Calorie Detection & Diet Recommendation. All rights reserved.</p>
  </footer>
</body>
</html>
