<?php
// Start session
session_start();

// Include database connection
require_once 'connection.php';


// Include fetch_disease_info.php
require_once 'fetch_disease_info.php';

// Function to fetch the user's calorie count
function fetchCalorieCount($pdo, $username) {
    // Fetch the user's calorie count from the database
    $query = "SELECT calorie_count FROM user_calories WHERE username = ? ORDER BY created_at DESC LIMIT 1";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$username]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the user's data is found in the database
    if ($userData) {
        // Extract calorie count from fetched data
        return (float)$userData['calorie_count'];
    }
    return 0;
}

// Fetch the user's username from the session
$username = isset($_SESSION["username"]) ? $_SESSION["username"] : '';

// Check if the user is logged in
if (!$username) {
    // If the user is not logged in, send an error response or redirect to login page
    echo "User not logged in";
    exit;
}

// Fetch the calorie count for the user
$calorie_count = fetchCalorieCount($pdo, $username);

// Store the calorie count in a session variable for future use
$_SESSION['calorie_count'] = $calorie_count;
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="path/to/html2pdf.js"></script>
    <title>Diet Planner</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        
        h1 {
            color: #333;
            text-align: center;
            margin-top: 20px;
        }
        
        .button-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
        
        .button-container button {
            padding: 12px 23px; /* Increased button size */
            font-size: 15px; /* Increased font size */
            border: none;
            border-radius: 30px; /* Rounded corners */
            background: linear-gradient(to right, #4caf50, #45a049); /* Gradient background */
            color: white;
            cursor: pointer;
            margin-right: 10px;
            transition: background-color 0.3s ease; /* Smooth hover transition */
        }
        
        .button-container button:hover {
            background: linear-gradient(to right, #45a049, #4caf50); /* Gradient background on hover */
        }
        
        .meal-container {
            display: table;
            position: relative;
            float: right;
            margin-left: auto;
            margin-right: auto;
            width: 30%;
        }
        
        .nutrition-table {
            position: fixed; /* Change to fixed */
            top: 40px; /* Adjust the top position */
            right: 20px; /* Adjust the right position */
            width: 30%;
            border-collapse: collapse;
            border-radius: 8px;
            background: linear-gradient(to bottom, #f9f9f9, #e6f2ff);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
 
        .nutrition-table th {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border-bottom: 2px solid #ddd;
            text-align: left;
        }

        .nutrition-table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            color: #333;
        }

        .nutrition-table td#totalCalories {
            color: #f50c0c;
        }

        .nutrition-table td#totalProtein {
            color: #1b95f2;
        }

        .nutrition-table td#totalCarbs {
            color: #fc9505;
        }

        .nutrition-table td#totalFats {
            color: #33852c;
        }
        
        .card {
            border-radius: 10px; /* Rounded corners */
            margin: 10px;
            padding: 20px; /* Increased padding */
            width: 80%;
        }
        
        .card-button {
            margin-bottom: 10px; /* Increased margin */
            background-color: #e8dbe7; /* Default button color */
            text-align: left;
            cursor: pointer;
            padding: 12px 20px; /* Increased padding */
            border-radius: 20px; /* Rounded corners */
            border: 2px solid transparent; /* Transparent border */
            transition: background-color 0.3s ease, border-color 0.3s ease; /* Smooth transition */
        }
        
        .card-button.selected {
            background-color: #65d3d6; /* Selected button color */
            border-color: #65d3d6; /* Border color on selection */
        }
        
        .container {
            display: none;
            border: 2px solid #ccc; /* Border style */
            padding: 30px; /* Increased padding */
            margin-top: 20px; /* Increased margin */
            width: 80%;
            border-radius: 15px; /* Rounded corners */
        }
        
        .containers {
            width: 40%;
            margin: 0 auto;
            padding: 20px;
        }
        
        .active {
            display: block;
        }

        .username-container {
            display: flex;
            position: fixed;
            top: 0;
            left: 0;
            font-size: 18px;
            font-weight: bold;
            color: #333;
            background-color: #ded9d9;
            padding: 25px 25px; /* Increase padding to make it taller */
            border-radius: 2px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
            z-index: 999; /* Ensure it's above other elements */
        }
        .username-container > div {
            margin-right: 20px; /* Add some spacing between the divs */
        }

        .added-items-table-container {
            border-collapse: collapse;
            border-radius: 8px;
            background: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 285px; /* Adjust as needed based on your layout */
            right: 20px;
            width: 35%;
            margin-left: 65%;
        }

        .added-items-table {
            width: 100%;
            border-collapse: collapse;
        }

        .added-items-table-container th,
        .added-items-table-container td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .added-items-table-container thead th {
            
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }

        .added-items-table-container tbody td {
            color: #666;
        }

        .added-items-table-container tbody tr:hover {
            background-color: #f2f2f2;
        }
    </style>
</head>
<d>
<div class="username-container">
    <div class="welcome">Welcome, <?php echo $username; ?>!</div>
       
        <form action="logout.php" method="post">
        <button type="submit" class="logout-button">Logout</button>
        
    </form>
</div>

</div>
    <h1>Diet Planner</h1>
    <div class="button-container">
        <button class="button1" id="button1">Breakfast</button>
        <button class="button2" id="button2">Lunch</button>
        <button class="button3" id="button3">Dinner</button>
    </div>
        <div id="containers" style= "float:left; width : 50%;">
            <div class="container" id="breakfast">
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                    <h5 class="card-title">Juices</h5>
                    <button type="button" class="card-button" onclick="additem('Pomegranate Juice')">
                        <span class="button-text">Pomegranate Juice(350g)</span>
                        <span class="button-icon">+</span>
                    </button>
        
                        <button type="button" class="card-button" onclick="additem('Strawberry Juice')">
                          <span class="button-text">Strawberry Juice(350g)</span>
                          <span class="button-icon">+</span></button>
                       
                      
                      <button type="button" class="card-button" onclick="additem('Papaya Juice')">
                          <span class="button-text">Papaya Juice(350g)</span>
                          <span class="button-icon">+</span>
                      </button>
    
                      <button type="button" class="card-button" onclick="additem('Apple Juice')">
                          <span class="button-text">Apple Juice(350g)</span>
                          <span class="button-icon">+</span>
                      </button>
                      <button type="button" class="card-button" onclick="additem('Mango Juice')">
                          <span class="button-text">Mango Juice(240g)</span>
                          <span class="button-icon">+</span>
                      </button>
                      
                    </div>
                  </div>
            
                  <div class="card" style="width: 18rem;">
                    <div class="card-body">
                    <h5 class="card-title">Breakfast Grains</h5>
                    <button type="button" class="card-button" onclick="additem('Brown Rices')">
                      <span class="button-text">Brown Rices(85g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Basmati Rices')">
                      <span class="button-text">Basmati Rices(100g)</span>
                      <span class="button-icon">+</span>
            </button>
                  <button type="button" class="card-button" onclick="additem('Sweet Corns')">
                      <span class="button-text">Sweet Corns(145g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Rolled Oatss')">
                      <span class="button-text">Rolled Oatss(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Quick Oatss')">
                      <span class="button-text">Quick Oatss(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Instant Oatss')">
                      <span class="button-text">Instant Oatss(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Whole Grain Wheat')">
                      <span class="button-text">Whole Grain Wheat(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Sprouts')">
                      <span class="button-text">Sprouts(50g)</span>
                      <span class="button-icon">+</span>
                  </button>
                    </div>
                  </div>
            
                  <div class="card" style="width: 18rem;">
                    <div class="card-body">
                    <h5 class="card-title">Protein</h5>
                    <button type="button" class="card-button" onclick="additem('Cheese')">
                      <span class="button-text">Cheese(36g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Cottage Cheese')">
                      <span class="button-text">Cottage Cheese(98g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Skim Milk')">
                      <span class="button-text">Skim Milk(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Low Fat Milk')">
                      <span class="button-text">Low Fat Milk(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Whole Milk')">
                      <span class="button-text">Whole Milk(103g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Soya Milk')">
                      <span class="button-text">Soya Milk(102g)</span>
                      <span class="button-icon">+</span>
                  </button>
                
                  <button type="button" class="card-button" onclick="additem('Buffalo Milk')">
                      <span class="button-text">Buffalo Milk(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Hot Chocolate')">
                      <span class="button-text">Hot Chocolate(200g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('White Hot Chocolate')">
                      <span class="button-text">White Hot Chocolate(350g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Coconut Hot Chocolate')">
                      <span class="button-text">Coconut Hot Chocolate(350g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Peanut Butter Hot Chocolate')">
                      <span class="button-text">Peanut Butter Hot Chocolate(350g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Mint Hot Chocolate')">
                      <span class="button-text">Mint Hot Chocolate(350g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Milkshake')">
                      <span class="button-text">Milkshake(350g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Protein Shake')">
                      <span class="button-text">Protein Shake(500g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Mango Lassi')">
                      <span class="button-text">Mango Lassi(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Vanilla Milkshake')">
                      <span class="button-text">Vanilla Milkshake(450g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Chocolate Milkshake')">
                      <span class="button-text">Chocolate Milkshake(450g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button"onclick="additem('Cashew Milkshake')">
                      <span class="button-text">Cashew Milkshake(450g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Eggs')">
                      <span class="button-text">Eggs(50g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Black Walnut')">
                      <span class="button-text">Black Walnut(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Soyanuts')">
                      <span class="button-text">Soyanuts(28g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Watermelon')">
                      <span class="button-text">Watermelon(286g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Veg Grilled Sandwich')">
                      <span class="button-text">Veg Grilled Sandwich(175g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Cheese Sandwich')">
                      <span class="button-text">Cheese Sandwich(125g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Paneer Sandwich')">
                      <span class="button-text">Paneer Sandwich(175g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Egg Sandwich')">
                      <span class="button-text">Egg Sandwich(175g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Peanut Butter and Jelly Sandwich')">
                      <span class="button-text">Peanut Butter and Jelly Sandwich(125g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Chicken Sandwich')">
                      <span class="button-text">Chicken Sandwich(175g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Corn and Cheese Sandwich')">
                      <span class="button-text">Corn and Cheese Sandwich(175g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Kidney Beans')">
                      <span class="button-text">Kidney Beans(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                    </div>
                  </div>
            
                  <div class="card" style="width: 18rem;">
                    <div class="card-body">
                    <h5 class="card-title">Fruites</h5>
                    <button type="button" class="card-button" onclick="additem('Apple')">
                      <span class="button-text">Apple(182g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Apricot')">
                      <span class="button-text">Apricot(55g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Avocado')">
                      <span class="button-text">Avocado(30g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Banana')">
                      <span class="button-text">Banana(118g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Black Chokeberry')">
                      <span class="button-text">Black Chokeberry(143g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Blackberries')">
                      <span class="button-text">Blackberries(144g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Blueberries')">
                      <span class="button-text">Blueberries(148g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Cherry')">
                      <span class="button-text">Cherry(140g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Date Palm')">
                      <span class="button-text">Date Palm(24g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Grapes')">
                      <span class="button-text">Grapes(92g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Guava')">
                      <span class="button-text">Guava(55g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Jackfruit')">
                      <span class="button-text">Jackfruit(165g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Kiwi')">
                      <span class="button-text">Kiwi(76g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Mango')">
                      <span class="button-text">Mango(165g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Orange')">
                      <span class="button-text">Orange(154g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Papaya')">
                      <span class="button-text">Papaya(140g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Pear')">
                      <span class="button-text">Pear(178g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Pineapple')">
                      <span class="button-text">Pineapple(165g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Plum')">
                      <span class="button-text">Plum(66g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Pomegranate')">
                      <span class="button-text">Pomegranate(282g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Raspberry')">
                      <span class="button-text">Raspberry(123g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Redberries')">
                      <span class="button-text">Redberries(123g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Strawberry')">
                      <span class="button-text">Strawberry(140g)</span>
                      <span class="button-icon">+</span>
                  </button>
                    </div>
                  </div>
            
                  <div class="card" style="width: 18rem;">
                    <div class="card-body">
                    <h5 class="card-title">Bread</h5>
                    <button type="button" class="card-button" onclick="additem('White Bread')">
                      <span class="button-text">White Bread(30g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Wheat Bread')">
                      <span class="button-text">Wheat Bread(33g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Whole Grain Bread')">
                      <span class="button-text">Whole Grain Bread(33g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Brown Bread')">
                      <span class="button-text">Brown Bread(33g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Multigrain Bread')">
                      <span class="button-text">Multigrain Bread(33g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Paav Bread')">
                      <span class="button-text">Paav Bread(55g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Bun Bread')">
                      <span class="button-text">Bun Bread(55g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  
                    </div>
                  </div>
                  <div class="card" style="width: 18rem;">
                    <div class="card-body">
                    <h5 class="card-title">Tea and Coffee</h5>
                    <button type="button" class="card-button" onclick="additem('Blak Coffee')">
                      <span class="button-text">Black Coffee(240g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Coffee with Cream and sugar')">
                      <span class="button-text">Coffee with Cream and sugar(240g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Black Tea')">
                      <span class="button-text">Black Tea(240g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Tea with Milk and sugar')">
                      <span class="button-text">Tea with Milk and sugar(240g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('hot choclate')">
                      <span class="button-text">hot choclate(200g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('chai')">
                      <span class="button-text">chai(240g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('espresso')">
                      <span class="button-text">espresso(30g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Cappuccino')">
                      <span class="button-text">Cappuccino(180g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Americano')">
                      <span class="button-text">Americano(240g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Masala chai')">
                      <span class="button-text">Masala chai(240g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Lemon ginger tea')">
                      <span class="button-text">Lemon ginger tea(200g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Cardamom coffee')">
                      <span class="button-text">Cardamom coffee(240g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Dalgona coffee')">
                      <span class="button-text">Dalgona coffee(200g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('milk tea')">
                      <span class="button-text">milk tea(400g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Boba tea')">
                      <span class="button-text">Boba tea(500g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Condensed milk')">
                      <span class="button-text">Condensed milk(110g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('skim milk')">
                      <span class="button-text">skim milk(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('low Fat milk')">
                      <span class="button-text">low Fat milk(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('whole milk')">
                      <span class="button-text">whole milk(103g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('soya milk')">
                      <span class="button-text">soya milk(102g)</span>
                      <span class="button-icon">+</span>
                  </button>
                  <button type="button" class="card-button" onclick="additem('Buffalo Milk')">
                      <span class="button-text">Buffalo Milk(100g)</span>
                      <span class="button-icon">+</span>
                  </button>
                    </div>
                  </div>
                </div>
        
                <div class="container" id="lunch">
                    <div class="card" style="width: 18rem;">
                        <div class="card-body">
                                        <h5 class="card-title">Grains</h5>
                                        <button type="button" class="card-button" onclick="additem('Harrd Red Wheat')">
                                            <span class="button-text">Harrd Red Wheat(100g)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('soft Red  Wheat')">
                                            <span class="button-text">soft Red  Wheat(100g)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Hard White Wheat')"> 
                                            <span class="button-text">Hard White Wheat(100)</span>
                                            <span class="button-icon">+</span> </button>
                                        <button type="button" class="card-button" onclick="additem('Soft White Wheat')">
                                            <span class="button-text">Soft White Wheat(100)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('White Rice')">
                                            <span class="button-text">White Rice(85)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Brown Rice')">
                                            <span class="button-text">Brown Rice(85)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Basmati Rice')">
                                            <span class="button-text">Basmati Rice(100)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('sweet corn')">
                                            <span class="button-text">sweet corn(145)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Popcorn')">
                                            <span class="button-text">Popcorn(24)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Rolled Oats')">
                                            <span class="button-text">Rolled Oats(100)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Quick Oats')">
                                            <span class="button-text">Quick Oats(100)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Instant Oats')">
                                            <span class="button-text">Instant Oats(100)</span>
                                            <span class="button-icon">+</span></button>
                                        </button>
                                        </div>
                                        </div>
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body">
                                                <h5 class="card-title">Bread</h5>
                                                <button type="button" class="card-button" onclick="additem('White Bread')">
                                                  <span class="button-text">White Bread(30g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Wheat Bread')">
                                                  <span class="button-text">Wheat Bread(33g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Whole Grain Bread')">
                                                  <span class="button-text">Whole Grain Bread(33g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Brown Bread')">
                                                  <span class="button-text">Brown Bread(33g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Multigrain Bread')">
                                                  <span class="button-text">Multigrain Bread(33g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Paav Bread')">
                                                  <span class="button-text">Paav Bread(55g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Bun Bread')">
                                                  <span class="button-text">Bun Bread(55g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                            </div>
                                        </div>
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body">
                                            <h5 class="card-title">Vegetable</h5>
                                                <button type="button" class="card-button" onclick="additem('Broccoli')">
                                                <span class="button-text">Broccoli(91g)</span>
                                            <span class="button-icon">+</span>
                                                </button>
                                                <button type="button" class="card-button" onclick="additem('Carrots')">
                                                <span class="button-text">Carrots(61g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Spinach')">
                                                <span class="button-text">Spinach(30g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Sweet Potato')">
                                                <span class="button-text">Sweet Potato(114g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Tomatoes')">
                                                <span class="button-text">Tomatoes(123g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                            
                                            <button type="button" class="card-button" onclick="additem('Beetroot')">
                                                <span class="button-text">Beetroot(136g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Cabbage')">
                                                <span class="button-text">Cabbage(70g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Cauliflower')">
                                                <span class="button-text">Cauliflower(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                            
                                            <button type="button" class="card-button" onclick="additem('Cucumber')">
                                                <span class="button-text">Cucumber(104g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Garlic')">
                                                <span class="button-text">Garlic(3g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Lettuce')">
                                                <span class="button-text">Lettuce(56g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Mushroom')">
                                                <span class="button-text">Mushroom(70g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Onion')">
                                                <span class="button-text">Onion(110g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Peas')">
                                                <span class="button-text">Peas(85g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Green Pepper')">
                                                <span class="button-text">Green Pepper(74g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Yellow Pepper')">
                                                <span class="button-text">Yellow Pepper(186g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Red Pepper')">
                                                <span class="button-text">Red Pepper(74g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Potato')">
                                                <span class="button-text">Potato(173g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                            
                                            <button type="button" class="card-button" onclick="additem('Pumpkin')">
                                                <span class="button-text">Pumpkin(116g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Radish')">
                                                <span class="button-text">Radish(116g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Eggplant')">
                                                <span class="button-text">Eggplant(82g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Bean Sprouts')">
                                                <span class="button-text">Bean Sprouts(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Bell Pepper')">
                                                <span class="button-text">Bell Pepper(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Capsicum')">
                                                <span class="button-text">Capsicum(75g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Green Beans')">
                                                <span class="button-text">Green Beans(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Kidney Beans')">
                                                <span class="button-text">Kidney Beans(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('New potato')">
                                                <span class="button-text">New potato(77g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Methi')">
                                                <span class="button-text">Methi(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Microgreens')">
                                                <span class="button-text">Microgreens(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                       
                                            </div>
                                        </div>
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body">
                                            <h5 class="card-title">Salads</h5>
                                            <button type="button" class="card-button" onclick="additem('potato salad')">
                                                <span class="button-text">potato salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Tuna salad')">
                                                <span class="button-text">Tuna salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Broccoli salad')">
                                                <span class="button-text">Broccoli salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Carrot salad')">
                                                <span class="button-text">Carrot salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('chickpea salad')">
                                                <span class="button-text">chickpea salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('cucumber salad')">
                                                <span class="button-text">cucumber salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Egg salad')">
                                                <span class="button-text">Egg salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Roasted beet salad')">
                                                <span class="button-text">Roasted beet salad(200g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Spinach salad')">
                                                <span class="button-text">Spinach salad(200g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Chinese chicken salad')">
                                                <span class="button-text">Chinese chicken salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Curried chicken salad')">
                                                <span class="button-text">Curried chicken salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Grilled corn salad')">
                                                <span class="button-text">Grilled corn salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Grilled shrimp and vegetable salad')">
                                                <span class="button-text">Grilled shrimp and vegetable salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                                                       
                                            </div>
                                        </div>
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body">
                                            <h5 class="card-title">Soup</h5>
                                            <button type="button" class="card-button" onclick="additem('chicken Noodle soup')">
                                                <span class="button-text">chicken Noodle soup(240g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Tomato soup')">
                                                <span class="button-text">Tomato soup(200g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('potato soup')">
                                                <span class="button-text">potato soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('vegetable soup')">
                                                <span class="button-text">vegetable soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('corn chowder soup')">
                                                <span class="button-text">corn chowder soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Broccoli cheddar soup')">
                                                <span class="button-text">Broccoli cheddar soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('cream of tomato soup')">
                                                <span class="button-text">cream of tomato soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('black beans soup')">
                                                <span class="button-text">black beans soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('chicken and Rice soup')">
                                                <span class="button-text">chicken and Rice soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('chicken and Dumpling soup')">
                                                <span class="button-text">chicken and Dumpling soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                                                      
                                        </div>
                                </div>
                            </div>

                <div class="container" id="dinner">
                    <div class="card" style="width: 18rem;">
                        <div class="card-body">
                                            <h5 class="card-title">Soup</h5>
                                            <button type="button" class="card-button" onclick="additem('chicken Noodle soup')">
                                                <span class="button-text">chicken Noodle soup(240g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Tomato soup')">
                                                <span class="button-text">Tomato soup(200g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('potato soup')">
                                                <span class="button-text">potato soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('vegetable soup')">
                                                <span class="button-text">vegetable soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('corn chowder soup')">
                                                <span class="button-text">corn chowder soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Broccoli cheddar soup')">
                                                <span class="button-text">Broccoli cheddar soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('cream of tomato soup')">
                                                <span class="button-text">cream of tomato soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('black beans soup')">
                                                <span class="button-text">black beans soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('chicken and Rice soup')">
                                                <span class="button-text">chicken and Rice soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('chicken and Dumpling soup')">
                                                <span class="button-text">chicken and Dumpling soup(245g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                                                      
                                        </div>
                                        </div>
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body">
                                        <h5 class="card-title">Grains</h5>
                                        <button type="button" class="card-button" onclick="additem('Harrd Red Wheat')">
                                            <span class="button-text">Harrd Red Wheat(100g)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('soft Red  Wheat')">
                                            <span class="button-text">soft Red  Wheat(100g)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Hard White Wheat')"> 
                                            <span class="button-text">Hard White Wheat(100)</span>
                                            <span class="button-icon">+</span> </button>
                                        <button type="button" class="card-button" onclick="additem('Soft White Wheat')">
                                            <span class="button-text">Soft White Wheat(100)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('White Rice')">
                                            <span class="button-text">White Rice(85)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Brown Rice')">
                                            <span class="button-text">Brown Rice(85)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Basmati Rice')">
                                            <span class="button-text">Basmati Rice(100)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('sweet corn')">
                                            <span class="button-text">sweet corn(145)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Popcorn')">
                                            <span class="button-text">Popcorn(24)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Rolled Oats')">
                                            <span class="button-text">Rolled Oats(100)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Quick Oats')">
                                            <span class="button-text">Quick Oats(100)</span>
                                            <span class="button-icon">+</span></button>
                                        <button type="button" class="card-button" onclick="additem('Instant Oats')">
                                            <span class="button-text">Instant Oats(100)</span>
                                            <span class="button-icon">+</span></button>
                                        </button>
                                        </div>
                                        </div>
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body">
                                            <h5 class="card-title">Vegetable</h5>
                                                <button type="button" class="card-button" onclick="additem('Broccoli')">
                                                <span class="button-text">Broccoli(91g)</span>
                                            <span class="button-icon">+</span>
                                                </button>
                                                <button type="button" class="card-button" onclick="additem('Carrots')">
                                                <span class="button-text">Carrots(61g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Spinach')">
                                                <span class="button-text">Spinach(30g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Sweet Potato')">
                                                <span class="button-text">Sweet Potato(114g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Tomatoes')">
                                                <span class="button-text">Tomatoes(123g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                            
                                            <button type="button" class="card-button" onclick="additem('Beetroot')">
                                                <span class="button-text">Beetroot(136g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Cabbage')">
                                                <span class="button-text">Cabbage(70g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Cauliflower')">
                                                <span class="button-text">Cauliflower(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                            
                                            <button type="button" class="card-button" onclick="additem('Cucumber')">
                                                <span class="button-text">Cucumber(104g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Garlic')">
                                                <span class="button-text">Garlic(3g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Lettuce')">
                                                <span class="button-text">Lettuce(56g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Mushroom')">
                                                <span class="button-text">Mushroom(70g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Onion')">
                                                <span class="button-text">Onion(110g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Peas')">
                                                <span class="button-text">Peas(85g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Green Pepper')">
                                                <span class="button-text">Green Pepper(74g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Yellow Pepper')">
                                                <span class="button-text">Yellow Pepper(186g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Red Pepper')">
                                                <span class="button-text">Red Pepper(74g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Potato')">
                                                <span class="button-text">Potato(173g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                            
                                            <button type="button" class="card-button" onclick="additem('Pumpkin')">
                                                <span class="button-text">Pumpkin(116g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Radish')">
                                                <span class="button-text">Radish(116g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Eggplant')">
                                                <span class="button-text">Eggplant(82g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Bean Sprouts')">
                                                <span class="button-text">Bean Sprouts(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Bell Pepper')">
                                                <span class="button-text">Bell Pepper(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Capsicum')">
                                                <span class="button-text">Capsicum(75g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Green Beans')">
                                                <span class="button-text">Green Beans(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Kidney Beans')">
                                                <span class="button-text">Kidney Beans(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('New potato')">
                                                <span class="button-text">New potato(77g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Methi')">
                                                <span class="button-text">Methi(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Microgreens')">
                                                <span class="button-text">Microgreens(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                       
                                            </div>
                                        </div>
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body">
                                                <h5 class="card-title">Bread</h5>
                                                <button type="button" class="card-button" onclick="additem('White Bread')">
                                                  <span class="button-text">White Bread(30g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Wheat Bread')">
                                                  <span class="button-text">Wheat Bread(33g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Whole Grain Bread')">
                                                  <span class="button-text">Whole Grain Bread(33g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Brown Bread')">
                                                  <span class="button-text">Brown Bread(33g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Multigrain Bread')">
                                                  <span class="button-text">Multigrain Bread(33g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Paav Bread')">
                                                  <span class="button-text">Paav Bread(55g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                              <button type="button" class="card-button" onclick="additem('Bun Bread')">
                                                  <span class="button-text">Bun Bread(55g)</span>
                                                  <span class="button-icon">+</span>
                                              </button>
                                            </div>
                                        </div>
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body">
                                            <h5 class="card-title">Salads</h5>
                                            <button type="button" class="card-button" onclick="additem('potato salad')">
                                                <span class="button-text">potato salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Tuna salad')">
                                                <span class="button-text">Tuna salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Broccoli salad')">
                                                <span class="button-text">Broccoli salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Carrot salad')">
                                                <span class="button-text">Carrot salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('chickpea salad')">
                                                <span class="button-text">chickpea salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('cucumber salad')">
                                                <span class="button-text">cucumber salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Egg salad')">
                                                <span class="button-text">Egg salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Roasted beet salad')">
                                                <span class="button-text">Roasted beet salad(200g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Spinach salad')">
                                                <span class="button-text">Spinach salad(200g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Chinese chicken salad')">
                                                <span class="button-text">Chinese chicken salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Curried chicken salad')">
                                                <span class="button-text">Curried chicken salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Grilled corn salad')">
                                                <span class="button-text">Grilled corn salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>
                                            <button type="button" class="card-button" onclick="additem('Grilled shrimp and vegetable salad')">
                                                <span class="button-text">Grilled shrimp and vegetable salad(100g)</span>
                                                <span class="button-icon">+</span>
                                            </button>                                                       
                                            </div>
                                 </div>
                </div>
        </div>
                     
        <table class="nutrition-table">
        <thead>    
            <tr>
                <th>Nutrient</th>
                <th>Amount</th>
            </tr>
            <tr>
                <td>Calories</td>
                <td id="totalCalories">0.00Kcal</td>

            </tr>
            <tr>
                <td>Proteins</td>
                <td id="totalProtein">0.00g</td>

            </tr>
            <tr>
                <td>Carbs</td>
                <td id="totalCarbs">0.00g</td>

            </tr>
            <tr>
                <td>Fats</td>
                <td id="totalFats">0.00g</td>

            </tr>
        </table>
        </thead>
  </table>
    </div>
    </div>
 <table class="added-items-table-container">
    <thead>
        <tr>
            <th>Breakfast</th>
            <th>Lunch</th>
            <th>Dinner</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="breakfast-column"></td>
            <td class="lunch-column"></td>
            <td class="dinner-column"></td>
        </tr>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3"><button id="download-pdf">Download PDF</button></td>
        </tr>
    </tfoot>
</table>

</body>
<script>
document.getElementById('button1').addEventListener('click', function() {
    document.querySelectorAll('.container').forEach(function(container) {
        container.classList.remove('active');
    });
    document.getElementById('breakfast').classList.add('active');

    // Show the added-items-table when breakfast button is clicked
    document.querySelector('.added-items-table-container').style.display = 'block';
});

document.getElementById('button2').addEventListener('click', function() {
    document.querySelectorAll('.container').forEach(function(container) {
        container.classList.remove('active');
    });
    document.getElementById('lunch').classList.add('active');

    // Show the added-items-table when lunch button is clicked
    document.querySelector('.added-items-table-container').style.display = 'block';
});

document.getElementById('button3').addEventListener('click', function() {
    document.querySelectorAll('.container').forEach(function(container) {
        container.classList.remove('active');
    });
    document.getElementById('dinner').classList.add('active');

    // Show the added-items-table when dinner button is clicked
    document.querySelector('.added-items-table-container').style.display = 'block';
});

      
document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.card-button');

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const isSelected = button.classList.contains('selected');
            const icon = button.querySelector('.button-icon');
            const foodItem = button.querySelector('.button-text').textContent;

            // Extract nutritional values of the food item
            const calories = parseFloat(button.dataset.calories);
            const protein = parseFloat(button.dataset.protein);
            const carbs = parseFloat(button.dataset.carbs);
            const fats = parseFloat(button.dataset.fats);

            if (isSelected) {
    // If already selected, remove from table and subtract values
    button.classList.remove('selected');
    icon.textContent = '+';
    icon.classList.remove('tick');

    // Negate the values before passing them to the function for subtraction
    removeItemFromTable(foodItem, -calories, -protein, -carbs, -fats); 
} else {
    // If not selected, add to table and add values
    button.classList.add('selected');
    icon.textContent = '✔';
    icon.classList.add('tick');
    
    // Determine the meal type based on the button's parent container
    const mealType = button.closest('.container').id;
    
    // Add the food item to the table with the determined meal type
    addItemToTable(foodItem, mealType);
}

        });
    });
});

function additem(foodItem) {
        // Send AJAX request to fetch Calories, Protein, Carbs, and Fats
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "fetch_nutrition.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    try {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // Update total values
                            updateTotalValues(response, 'add');
                        } else {
                            alert("Failed to fetch nutrition data for " + foodItem);
                        }
                    } catch (error) {
                        console.error("Error parsing response:", error);
                        alert("Error parsing response: " + error.message);
                    }
                } else {
                    alert("HTTP Error: " + xhr.status);
                }
            }
        };
        xhr.send("food_item=" + encodeURIComponent(foodItem));
    }

function updateTotalValues(data, operation) {
    var totalCalories = parseFloat(document.getElementById("totalCalories").textContent);
    var totalProtein = parseFloat(document.getElementById("totalProtein").textContent);
    var totalCarbs = parseFloat(document.getElementById("totalCarbs").textContent);
    var totalFats = parseFloat(document.getElementById("totalFats").textContent);

    if (operation === 'add') {
        totalCalories += parseFloat(data.calories);
        totalProtein += parseFloat(data.protein);
        totalCarbs += parseFloat(data.carbs);
        totalFats += parseFloat(data.fats);
    } else if (operation === 'subtract') {
        totalCalories -= parseFloat(data.calories);
        totalProtein -= parseFloat(data.protein);
        totalCarbs -= parseFloat(data.carbs);
        totalFats -= parseFloat(data.fats);
    }

    document.getElementById("totalCalories").textContent = totalCalories.toFixed(3);
    document.getElementById("totalProtein").textContent = totalProtein.toFixed(3);
    document.getElementById("totalCarbs").textContent = totalCarbs.toFixed(3);
    document.getElementById("totalFats").textContent = totalFats.toFixed(3);

    // Check if total calories exceed the calorie count
    // Define protein, carbs, and fats limits
    var proteinLimit = <?php echo $diseaseData['Protein_g']; ?>;
    var carbsLimit = <?php echo $diseaseData['Carbs_g']; ?>;
    var fatsLimit = <?php echo $diseaseData['Total_Fat_g']; ?>;
    var calorieLimit = <?php echo $calorie_count; ?>;

    // Check if total protein exceeds the limit
    if (totalProtein > proteinLimit) {
        alert("Total protein exceeds your limit!");
    }

    // Check if total carbs exceed the limit
    if (totalCarbs > carbsLimit) {
        alert("Total carbs exceed your limit!");
    }

    // Check if total fats exceed the limit
    if (totalFats > fatsLimit) {
        alert("Total fats exceed your limit!");
    }

    // Check if total calories exceed the calorie count
    if (totalCalories > calorieLimit) {
        alert("Total calories exceed your calorie limit!");
        // You can also add additional actions here, such as disabling further additions or highlighting the exceeded calories.
    }
}


function addItemToTable(foodItem, mealType = 'generic') {
    // Add to the new table
    var addedItemsTableBody = document.querySelector('.added-items-table-container tbody');
    var newRow = document.createElement('tr');
    var foodItemCell = document.createElement('td');
    foodItemCell.textContent = foodItem; // Set the text content to the food item
    newRow.appendChild(foodItemCell);

    // Append the row to the appropriate column based on the meal type
    var mealTypeColumn = document.querySelector(`.added-items-table-container tbody .${mealType}-column`);
    if (mealTypeColumn) {
        mealTypeColumn.appendChild(newRow);
    } else {
        // If the meal type is not recognized, default to adding to the generic column
        addedItemsTableBody.appendChild(newRow);
    }
}

    // Function to remove items from the new table
    function removeItemFromTable(foodItem) {
        var addedItemsTableBody = document.querySelector('.added-items-table-container tbody');
        var rows = addedItemsTableBody.querySelectorAll('tr');
        rows.forEach(function(row) {
            if (row.querySelector('td').textContent === foodItem) {
                row.remove();
            }
        });
}

</script>

</html>
