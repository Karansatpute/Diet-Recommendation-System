<?php
// Include database connection
require_once 'connection.php';

// Fetch the user's username from the session
$username = isset($_SESSION["username"]) ? $_SESSION["username"] : '';

// Check if the user is logged in
if (!$username) {
    // If the user is not logged in, send an error response or redirect to login page
    echo "User not logged in";
    exit;
}

// Fetch the selected disease for the user
$query = "SELECT selected_diseases FROM user_data WHERE username = ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$username]);
$userData = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the user's data is found in the database
if ($userData && isset($userData['selected_diseases'])) {
    // Extract selected disease from fetched data
    $selectedDisease = $userData['selected_diseases'];
    
    // Fetch information about protein, carbs, and fats for the selected disease from the final_diseases dataset
    $query = "SELECT Protein_g, Carbs_g, Total_Fat_g FROM final_diseases WHERE Disease = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$selectedDisease]);
    $diseaseData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Check if the disease data is found in the database
    if ($diseaseData) {
        // Display the fetched information
        echo "Disease: " . $selectedDisease . "<br>";
        echo "Protein: " . $diseaseData['Protein_g'] . "g<br>";
        echo "Carbs: " . $diseaseData['Carbs_g'] . "g<br>";
        echo "Fats: " . $diseaseData['Total_Fat_g'] . "g<br>";

        $proteinLimit = $diseaseData['Protein_g'];
        $carbsLimit = $diseaseData['Carbs_g'];
        $fatsLimit = $diseaseData['Total_Fat_g'];
    } else {
        echo "No information found for the selected disease";
    }
} else {
    echo "No disease information found for the user";
}
?>
