<?php
// Establish connection to MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$database = "diet";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the food item from the POST request
$foodItem = $_POST['food_item'];

// Initialize response array
$response = array('success' => false);

// Query to fetch calories from calorie_value table
$caloriesQuery = "SELECT ROUND(`Calories`, 3) AS `Calories` FROM `calorie_value` WHERE `food items` = ?";
$stmtCalories = $conn->prepare($caloriesQuery);
$stmtCalories->bind_param("s", $foodItem);
$stmtCalories->execute();
$resultCalories = $stmtCalories->get_result();

if ($resultCalories->num_rows > 0) {
    $rowCalories = $resultCalories->fetch_assoc();
    $calories = $rowCalories['Calories'];
} else {
    $calories = 0; // Default to 0 if food item not found
}

// Query to fetch protein, fats, and carbs from final_food_items table
$nutritionQuery = "SELECT ROUND(`Protein`, 6) AS `Protein`, ROUND(`Carbs`, 6) AS `Carbs`, ROUND(`Fats`, 6) AS `Fats` FROM `final_food_items` WHERE `food items` = ?";
$stmtNutrition = $conn->prepare($nutritionQuery);
$stmtNutrition->bind_param("s", $foodItem);
$stmtNutrition->execute();
$resultNutrition = $stmtNutrition->get_result();

if ($resultNutrition->num_rows > 0) {
    $rowNutrition = $resultNutrition->fetch_assoc();
    $protein = $rowNutrition['Protein'];
    $fats = $rowNutrition['Fats'];
    $carbs = $rowNutrition['Carbs'];
} else {
    $protein = 0;
    $fats = 0;
    $carbs = 0;
}

// Construct response array
$response = array(
    'success' => true,
    'calories' => (float)$calories,
    'protein' => (float)$protein,
    'fats' => (float)$fats,
    'carbs' => (float)$carbs
);

// Log the response before sending
error_log("Response: " . json_encode($response));

// Send response as JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close MySQL connection
$stmtCalories->close();
$stmtNutrition->close();
$conn->close();
?>
