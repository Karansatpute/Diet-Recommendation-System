<!DOCTYPE html>
<html>
<head>
    <title>User Sign up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            font-size: 18px;
            background-image: url('images/signup.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        nav {
			background-color: #333;
			color: #fff;
			display: flex;
			justify-content: space-between;
			padding: 2px;
			position: fixed;
			top: 0;
			width: 100%;
			z-index: 999;
		}

		nav ul {
			display: flex;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		nav li {
			margin-right: 20px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 4px;
		}
        .container {
            max-width: 300px;
            margin: 0 auto; /* This will center the container horizontally */
            padding: 40px;
            top: 10;
            background-color: rgba(242, 242, 242, 0); /* Set alpha value to 0 for full transparency */
            border-radius: 6px;
            margin-left: auto; /* Align container to the right side */
            margin-right: 120px; /* Add some space from the right edge */
        }
        h2 {
            text-align: center;
            margin-left: auto;
            margin-right: 45px;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="password"],
        input[type="email"] {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            display: block;
            margin-top: 20px;
            width: 100%;
            cursor: pointer;
        }

        .error-message {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Sign up</h2>
        <form id="registrationForm" action="register.php" method="POST" onsubmit="return validateForm()">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" required>
            <br><br>
            <label for="address">Address:</label>
            <input type="text" name="address" id="address" required>
            <br><br>
            <label for="mobile_no">Mobile No:</label>
            <input type="text" name="mobile_no" id="mobile_no" required pattern="[0-9]{10}" title="Please enter a valid 10-digit mobile number">
            <br><br>
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
            <br><br>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required minlength="8">
            <br><br>
            <input type="submit" value="Create Account">
        </form>
    </div>

    <script>
        function validateForm() {
    var form = document.getElementById("registrationForm");
    var mobileNo = form.elements["mobile_no"].value;
    var password = form.elements["password"].value;
    var confirmPassword = form.elements["confirm_password"].value;
    var email = form.elements["email"].value;
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    var allowedDomains = ["gmail.com", "outlook.com"]; // Add more domains as needed

    if (!mobileNo.match(/^[0-9]{10}$/)) {
        alert("Please enter a valid 10-digit mobile number");
        return false;
    }

    if (password.length < 8) {
        alert("Password must be at least 8 characters long");
        return false;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match");
        return false;
    }

    if (!email.match(emailPattern)) {
        alert("Please enter a valid email address");
        return false;
    }

    // Extract domain from email
    var domain = email.substring(email.lastIndexOf("@") + 1);
    // Check if the domain is allowed
    if (!allowedDomains.includes(domain)) {
        alert("Enter valid email");
        return false;
    }

    return true;
}

    </script>
</body>
</html>
