<?php
// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION["login_success"]) || $_SESSION["login_success"] !== true) {
    // Redirect the user to the login page if not logged in
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diet Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        h1 {
            color: #333;
            text-align: center;
            margin-top: 20px;
        }

        .form-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between; /* Adjusted to space between */
        }
        
        .column {
            flex: 1;
            margin-right: 10px; /* Adjusted margin between columns */
        }
        
        .column:last-child {
            margin-right: 0;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        input[type="number"],
        select {
            width: 100%;
            padding: 12px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }

        input[type="number"]:focus,
        select:focus {
            border-color: #4CAF50;
        }

        input[type="submit"],
        input[type="button"] {
            width: calc(50% - 5px); /* Adjusted width for each button */
            padding: 14px;
            border: none;
            border-radius: 6px;
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        /* Hover effect */
        input[type="submit"]:hover,
        input[type="button"]:hover {
            background-color: #45a049;
        }

        #calorieMessage {
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
            color: #333;
        }

        #selectedDiseasesContainer {
            max-height: 200px; /* Adjust the max height as needed */
            overflow-y: auto; /* Enable vertical scrolling */
            border: 1px solid #ccc;
            border-radius: 6px;
            padding: 10px;
            margin-top: 20px;
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: white;
        }


        #selectedDiseases table {
            width: 100%;
            border-collapse: collapse;
        }

        #selectedDiseases th, #selectedDiseases td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        #selectedDiseases th {
            background-color: #f2f2f2;
        }

        .removeButton {
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .removeButton:hover {
            background-color: #d32f2f;
        }
        /* Style for the arrow button */
        .arrowButton {
            background-color: #12bcff;
            color: white;
            border: none;
            border-radius: 50%; /* Makes the button round */
            width: 50px; /* Adjust width and height as needed */
            height: 50px;
            font-size: 24px; /* Adjust font size as needed */
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .arrowButton:hover {
            background-color: #1278ff;
        }
        .username-container {
            position: fixed;
            top: 20px;
            left: 20px;
            font-size: 18px;
            font-weight: bold;
            color: #333;
            background-color: #ded9d9;
            padding: 10px 20px;
            border-radius: 30px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.6);
            z-index: 999; /* Ensure it's above other elements */
        }

    </style>
</head>
<body>
    <div class="username-container">
        <?php echo $_SESSION["username"];?>
    </div>
    <h1>Diet Calculator</h1>
    <form id="dietForm" class="form-container" method="post" action="user_data.php"> <!-- Changed method and action -->
        <div class="column">
            <label for="weight">Weight (kg):</label>
            <input type="number" id="weight" name="weight" required>

            <label for="height">Height (cm):</label>
            <input type="number" id="height" name="height" required>

            <label for="age">Age:</label>
            <input type="number" id="age" name="age" required>

            <label for="gender">Gender:</label>
            <select id="gender" name="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>
        </div>
        <div class="column">
            <label for="activity_level">Activity Level:</label>
            <select id="activity_level" name="activity_level" required>
                <option value="sedentary">Sedentary</option>
                <option value="lightly_active">Lightly Active</option>
                <option value="moderately_active">Moderately Active</option>
                <option value="very_active">Very Active</option>
                <option value="extra_active">Extra Active</option>
            </select>

            <label for="selected_disease">Any Medical Condition:</label>
            <select id="selected_disease" name="selected_disease[]" required multiple>
                <!-- Options for medical conditions -->
                <option value="Coeliac disease">Coeliac disease</option>
                <option value="Hypothyroidism">Hypothyroidism</option>
                <option value="Hyperthyroidism">Hyperthyroidism</option>
                <option value="Diabetes insipidus">Diabetes insipidus</option>
                <option value="Frozen Shoulder">Frozen Shoulder</option>
                <option value="Trigger Finger">Trigger Finger</option>
                <option value="Haemochromatosis">Haemochromatosis</option>
                <option value="Acute Pancreatitis">Acute Pancreatitis</option>
                <option value="Chronic Pancreatitis">Chronic Pancreatitis</option>
                <option value="Nausea and vomiting">Nausea and vomiting</option>
                <option value="Migraine">Migraine</option>
                <option value="Mononucleosis">Mononucleosis</option>
                <option value="Stomach aches">Stomach aches</option>
                <option value="Conjunctivitis">Conjunctivitis</option>
                <option value="Dry Mouth">Dry Mouth</option>
                <option value="Acne">Acne</option>
                <option value="Malnutrition">Malnutrition</option>
                <option value="Diabetes">Diabetes</option>
                <option value="Kidney Infection">Kidney Infection</option>
                <option value="Obstructive Sleep Apnea">Obstructive Sleep Apnea</option>
                <option value="Thyroid">Thyroid</option>
                <option value="Scleroderma">Scleroderma</option>
                <option value="Acromegaly">Acromegaly</option>
                <option value="Phoechromocytoma">Phoechromocytoma</option>
                <option value="Lupus">Lupus</option>
                <option value="Cushing Syndrome">Cushing Syndrome</option>
                <option value="Hypertension">Hypertension</option>
                <option value="Type 2 Diabetes">Type 2 Diabetes</option>
                <option value="High blood pressure">High blood pressure</option>
                <option value="Heart Disease">Heart Disease</option>
                <option value="Stroke">Stroke</option>
                <option value="Sleep apnea">Sleep apnea</option>
                <option value="Metabolic syndrome">Metabolic syndrome</option>
                <option value="Fatty liver disease">Fatty liver disease</option>
                <option value="Osteoarthritis">Osteoarthritis</option>
                <option value="Gallbladder diseases">Gallbladder diseases</option>
                <option value="Kidney Diseases">Kidney Diseases</option>
                <option value="Measles">Measles</option>
                <option value="Mouth Ulcer">Mouth Ulce</option>
                <option value="Sore Throat">Sore Throat</option>
                <option value="Yellow Fever">Yellow Fever</option> 
            </select>


            <input id="calculateButton" type="button" value="Calculate BMR"> <!-- Changed to type="button" -->
            <input id="confirmButton" type="submit" value="Confirm"> <!-- New "Confirm" button -->
            <input type="hidden" id="calorie_count" name="calorie_count">



        </div>
    </form>
    <div id="calorieMessage"></div>
    <div id="calorie_count"></div>
    <div id="selectedDiseasesContainer">
        <table id="selectedDiseases">
            <tr><th>

            </th></tr>
        </table>
    </div>

    <script>
        function updateSelectedDiseasesTable() {
            var selectedDiseasesTable = document.getElementById('selectedDiseases');
            selectedDiseasesTable.innerHTML = '<tr><th>Selected Diseases</th></tr>'; // Clear previous selections
            
            var selectedDiseases = [];
            var options = document.getElementById('selected_disease').options;
            for (var i = 0; i < options.length; i++) {
                if (options[i].selected || options[i].getAttribute('data-selected') === 'true') {
                    selectedDiseases.push(options[i].text);
                }
            }

            // Update the selected diseases table with all selected diseases
            for (var j = 0; j < selectedDiseases.length; j++) {
                var newRow = selectedDiseasesTable.insertRow();
                var cell = newRow.insertCell(0);
                cell.textContent = selectedDiseases[j];
                var removeButton = document.createElement('button');
                removeButton.textContent = 'Remove';
                removeButton.className = 'removeButton';
                removeButton.onclick = function(disease) {
                    return function() {
                        var select = document.getElementById('selected_disease');
                        var options = select.options;
                        for (var i = 0; i < options.length; i++) {
                            if (options[i].text === disease) {
                                options[i].selected = false;
                                options[i].removeAttribute('data-selected');
                                break;
                            }
                        }
                        updateSelectedDiseasesTable();
                    };
                }(selectedDiseases[j]);
                cell.appendChild(removeButton);
            }
        }

        // Event listener for select dropdown change
        document.getElementById('selected_disease').addEventListener('click', function(event) {
            var target = event.target;
            if (target.tagName === 'OPTION') {
                var selected = target.selected;
                target.setAttribute('data-selected', selected);
            }
            updateSelectedDiseasesTable();
        });

        // Display selected diseases on page load
        window.addEventListener('load', function() {
            updateSelectedDiseasesTable();
        });

        function calculate_bmr(weight, height, age, gender) {
            // Function to calculate BMR based on gender
            if (gender == 'male') {
                return 10 * weight + 6.25 * height - 5 * age + 5;
            } else if (gender == 'female') {
                return 10 * weight + 6.25 * height - 5 * age - 161;
            } else if (gender == 'other') {
                // Adjusted formula for "other" gender
                return 10 * weight + 6.25 * height - 5 * age + 2;
            } else {
                console.log('Invalid gender');
                return null;
            }
        }

        function calculate_calories(bmr, activity_level) {
            // Function to calculate daily calorie requirements based on activity level 
            let activityMultiplier;

            switch (activity_level) {
                case 'sedentary':
                    activityMultiplier = 1.2;
                    break;
                case 'lightly_active':
                    activityMultiplier = 1.375;
                    break;
                case 'moderately_active':
                    activityMultiplier = 1.55;
                    break;
                case 'very_active':
                    activityMultiplier = 1.725;
                    break;
                case 'extra_active':
                    activityMultiplier = 1.9;
                    break;
                default:
                    console.log('Invalid activity level');
                    return null;
            }


            return bmr * activityMultiplier;
        }
        // Initially disable the confirm button
            document.getElementById('confirmButton').disabled = true;

            // Event listener for calculate button
// Event listener for calculate button
document.getElementById('calculateButton').addEventListener('click', function() {
    // Validate input fields
    var weight = parseFloat(document.getElementById('weight').value);
    var height = parseFloat(document.getElementById('height').value);
    var age = parseInt(document.getElementById('age').value);
    var gender = document.getElementById('gender').value;
    var activity_level = document.getElementById('activity_level').value;

    if (isNaN(weight) || isNaN(height) || isNaN(age)) {
        alert('Please enter the values for weight, height, and age.');
        return;
    }

    var bmr = calculate_bmr(weight, height, age, gender);
    if (bmr !== null) {
        var calories = calculate_calories(bmr, activity_level);
        if (calories !== null) {
            // Set the calculated calorie count value to the input field
            document.getElementById('calorie_count').value = calories.toFixed(2);

            document.getElementById('calorieMessage').textContent = 'Your daily calorie requirement is: ' + calories.toFixed(2) + ' calories';

            // Enable the confirm button
            document.getElementById('confirmButton').disabled = false;
        }
    }
});


            // Reset confirm button to disabled state when the form is reset
            document.getElementById('dietForm').addEventListener('reset', function() {
                document.getElementById('confirmButton').disabled = true;
            });
    </script>
</body>
</html>
