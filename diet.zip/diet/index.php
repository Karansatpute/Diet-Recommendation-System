<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Calorie Detection & Diet Recommendation- Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 0;
            margin: 0;
            font-size: 18px;
            background-image: url('images/home-back.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 0.5px;
            display: flex;
            justify-content: center; /* Center align */
            align-items: center;
            position: fixed;
            top: 50px;
            width: 100%;
            z-index: 999;
            right: 0;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 20px; /* Round shape for Login and Sign up buttons */
            border: none;
            margin-left: 15px;
        }

        .btn-square {
            background-color: #57cf3c;
            color: black;
            border-radius: 15px; /* Square shape for Home, Services, Contact us, Feedback buttons */
        }

        .btn-square:hover {
            background-color: #3c9f2d;
        }

        .btn-round {
            background-color: #f26666;
            color: black;
        }

        .btn-round:hover {
            background-color: #f53c2f;
        }

        .login-signup {
            margin-left: 350px; /* Adjust the distance between Home, Services, etc. and Login, Sign up */
            margin-right: 1px;

        }

        .nutri-track {
            position: relative;
            text-align: center;
            top: 70px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 60px;
            color: #57cf3c;
            text-shadow: 2px 2px 4px #000;
        }

        .right-text {
            position: absolute;
            top: 450px;
            right: 270px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 25px;
            color: #333;
            text-align: right;
        }

        .text {
            margin-top: 0;
        }

        .bold {
            font-weight: bold;
        }

        .italic {
            font-style: italic;
        }

    </style>
</head>
<body>
<div class="container">
    <a class="btn btn-square" href="">Home</a>
    <a class="btn btn-square" href="about_us.php">About us</a>
    <span class="login-signup">
        <a class="btn btn-round" href="customer_login.php">Login</a>
        <a class="btn btn-round" href="create_account.php">Sign up</a>
    </span>
</div>

<br>
<center>
    <h1 class="nutri-track">Nutri-Track</h1>
</center>
<div class="right-text">
    <p class="text"><span class="italic"><span class="bold">"Discover, Track, Transform :</span><br><span class="bold"></span></span> <span class="bold italic">Your Diet Journey Starts Here"</span></p>
</div>
</body>
</html>
