<?php
// Start session
session_start();

// Establish database connection
$servername = "localhost";
$username = "root";
$password = ""; // No password set for XAMPP MySQL
$dbname = "diet"; // Name of your database

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$username = $_POST["username"];
$password = $_POST["password"];

// Check if username and password match
$sql = "SELECT * FROM user WHERE user_name = '$username' AND password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Login successful
    $_SESSION["login_success"] = true;
    $_SESSION["username"] = $username; // Store username in session
    echo '<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Login Successful</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 0;
                        padding: 0;
                        background-color: #f8f9fa;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        background-image: url("images/back1.jpg");
                        background-size: cover;
                        background-position: center;
                    }

                    .container {
                        width: 350px;
                        padding: 40px;
                        background-color: rgba(255, 255, 255, 0.8);
                        border-radius: 8px;
                        box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
                    }

                    h2 {
                        text-align: center;
                        margin-bottom: 20px;
                        color: #333;
                    }

                    p {
                        text-align: center;
                        margin-bottom: 30px;
                        color: #555;
                    }

                    .button {
                        display: block;
                        width: 100%;
                        padding: 10px;
                        background-color: #007bff;
                        color: #fff;
                        text-align: center;
                        text-decoration: none;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        transition: background-color 0.3s ease;
                    }

                    .Button {
                        display: block;
                        width: 100%;
                        padding: 10px;
                        background-color: #1e9e05;
                        color: #fff;
                        text-align: center;
                        text-decoration: none;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        transition: background-color 0.3s ease;
                    }

                    .button:hover {
                        background-color: #0056b3;
                    }

                    .Button:hover {
                        background-color: #187a05;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h2>Login Successful</h2>
                    <p>Welcome, ' . $username . ' !</p>
                    <a href="calculate_diet.php" class="button">Create Diet</a>
                    <br>
                    <a href="create_meal.php" class="Button">Food Nutrient Content</a>
                </div>
            </body>
            </html>';
} else {
    // Login failed
    echo '<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Login Failed</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 0;
                        padding: 0;
                        background-color: #f8f9fa;
                        background-image: url("background.jpg");
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        background-size: cover;
                        background-position: center;
                    }

                    .container {
                        width: 350px;
                        padding: 40px;
                        background-color: rgba(255, 255, 255, 0.8);
                        border-radius: 8px;
                        box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
                    }

                    h2 {
                        text-align: center;
                        margin-bottom: 20px;
                        color: #333;
                    }

                    p {
                        text-align: center;
                        margin-bottom: 30px;
                        color: #555;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h2>Login Failed</h2>
                    <p>Invalid username or password. Please try again.</p>
                </div>
            </body>
            </html>';
}

$conn->close();
?>
