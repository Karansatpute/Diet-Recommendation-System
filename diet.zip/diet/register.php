<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = ""; // No password set for XAMPP MySQL
$dbname = "diet"; // Name of your database

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize message variable
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["name"];
    $address = $_POST["address"];
    $mobile_no = $_POST["mobile_no"];
    $password = $_POST["password"];
    $email = $_POST["email"];

    // Check if mobile number already exists
    $check_mobile_sql = "SELECT * FROM user WHERE mobile_no = '$mobile_no'";
    $check_mobile_result = $conn->query($check_mobile_sql);
    if ($check_mobile_result->num_rows > 0) {
        $message = "Error: Mobile number already exists.";
    } else {
        // Check if email already exists
        $check_email_sql = "SELECT * FROM user WHERE email = '$email'";
        $check_email_result = $conn->query($check_email_sql);
        if ($check_email_result->num_rows > 0) {
            $message = "Error: Email already exists.";
        } else {
            // Insert data into the database
            $sql = "INSERT INTO user (user_name, user_address, mobile_no, password, email)
                    VALUES ('$username', '$address', '$mobile_no', '$password', '$email')";
            
            if ($conn->query($sql) === TRUE) {
                $message = "Account created successfully.";
            } else {
                $message = "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Account Creation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        nav {
			background-color: #333;
			color: #fff;
			display: flex;
			justify-content: space-between;
			padding: 2px;
			position: fixed;
			top: 0;
			width: 100%;
			z-index: 999;
		}

		nav ul {
			display: flex;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		nav li {
			margin-right: 20px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 4px;
		}
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        
        h2 {
            text-align: center;
        }
        
        .message {
            margin-top: 20px;
            text-align: center;
            font-weight: bold;
            color: <?php echo ($message === "Account created successfully.") ? "#006400" : "#FF0000"; ?>;
        }
        
        .back-button {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-button a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #428bca;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        
        .back-button a:hover {
            background-color: #3071a9;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="message">
        <?php echo $message; ?>
    </div>
    <div class="back-button">
        <a href="index.php">Click here to Login</a>
    </div>
</div>

</body>
</html>
