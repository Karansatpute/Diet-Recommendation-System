<?php
// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION["login_success"]) || $_SESSION["login_success"] !== true) {
    // Redirect the user to the login page if not logged in
    header("Location: index.php");
    exit;
}

// Establish database connection
$servername = "localhost";
$username = "root";
$password = ""; // No password set for XAMPP MySQL
$dbname = "diet"; // Name of your database

// Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve username from session
$username = $_SESSION["username"];

// Fetch user_id from user table based on username
$sql_user_id = "SELECT user_id FROM user WHERE user_name = ?";
$stmt_user_id = $conn->prepare($sql_user_id);
$stmt_user_id->bind_param("s", $username);
$stmt_user_id->execute();
$result_user_id = $stmt_user_id->get_result();

if ($result_user_id->num_rows > 0) {
    $row = $result_user_id->fetch_assoc();
    $user_id = $row["user_id"];

    // Get the values from the form
    $weight = (float)$_POST["weight"]; // Ensure weight is a float
    $height = (float)$_POST["height"]; // Ensure height is a float
    $age = (int)$_POST["age"]; // Ensure age is an integer
    $gender = $_POST["gender"]; // Assuming gender is a string
    $activity_level = $_POST["activity_level"]; // Assuming activity_level is a string
    $selected_diseases = implode(", ", $_POST["selected_disease"]); // Convert array to comma-separated string
    $calorie_count = (float)$_POST["calorie_count"]; // Ensure calorie_count is a float

    // Debugging: Check if the calorie count is retrieved correctly
    echo "Calorie Count: " . $calorie_count . "<br>";

    // Insert or update user data
    $sql_check_user_data = "SELECT * FROM user_data WHERE user_id = ?";
    $stmt_check_user_data = $conn->prepare($sql_check_user_data);
    $stmt_check_user_data->bind_param("i", $user_id);
    $stmt_check_user_data->execute();
    $result_check_user_data = $stmt_check_user_data->get_result();

    if ($result_check_user_data->num_rows > 0) {
        // User data exists, update the record
        $sql_update_user_data = "UPDATE user_data SET weight=?, height=?, age=?, gender=?, activity_level=?, selected_diseases=? WHERE user_id=?";
        $stmt_update_user_data = $conn->prepare($sql_update_user_data);
        $stmt_update_user_data->bind_param("ddisssi", $weight, $height, $age, $gender, $activity_level, $selected_diseases, $user_id);

        if ($stmt_update_user_data->execute()) {
            echo "User data updated successfully.";
        } else {
            echo "Error updating user data: " . $stmt_update_user_data->error;
        }

        $stmt_update_user_data->close();
    } else {
        // User data doesn't exist, insert a new record
        $sql_insert_user_data = "INSERT INTO user_data (user_id, username, weight, height, age, gender, activity_level, selected_diseases) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert_user_data = $conn->prepare($sql_insert_user_data);
        $stmt_insert_user_data->bind_param("isddisss", $user_id, $username, $weight, $height, $age, $gender, $activity_level, $selected_diseases);

        if ($stmt_insert_user_data->execute()) {
            echo "User data inserted successfully.";
        } else {
            echo "Error inserting user data: " . $stmt_insert_user_data->error;
        }

        $stmt_insert_user_data->close();
    }

    // Insert calorie count into user_calories table
    $sql_insert_calories = "INSERT INTO user_calories (user_id, username, calorie_count) VALUES (?, ?, ?)";
    $stmt_insert_calories = $conn->prepare($sql_insert_calories);
    $stmt_insert_calories->bind_param("isd", $user_id, $username, $calorie_count);

    if ($stmt_insert_calories->execute()) {
        // Close prepared statement
        $stmt_insert_calories->close();
        
        // Redirect after successful insertion
        header("Location: meal_planner.php");
        exit;
    } else {
        // Show a user-friendly error message
        echo "Error inserting calorie count. Please try again later.";
    }
} else {
    echo "User not found.";
}

// Close prepared statement
$stmt_user_id->close();

// Close database connection
$conn->close();
?>
