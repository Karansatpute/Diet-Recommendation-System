<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            font-size: 18px;
            background-image: url('images/login1.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        nav {
			background-color: #333;
			color: #fff;
			display: flex;
			justify-content: space-between;
			padding: 2px;
			position: fixed;
			top: 0;
			width: 100%;
			z-index: 999;
		}

		nav ul {
			display: flex;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		nav li {
			margin-right: 20px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 4px;
		}
        .container {
        max-width: 300px;
        margin: 0 auto; /* This will center the container horizontally */
        padding: 100px;
        top: 10;
        background-color: rgba(242, 242, 242, 0); /* Set alpha value to 0 for full transparency */
        border-radius: 6px;
        margin-left: auto; /* Align container to the right side */
        margin-right: 120px; /* Add some space from the right edge */
    }
        h2 {
            text-align: center;
            margin-left: auto;
            margin-right: 45px;
        }

        label {
            display: block;
            margin-bottom: 16px;
        }

        input[type="text"],
        input[type="password"] {
            width: 88%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            display: block;
            margin-top: 20px;
            width: 95%;
            cursor: pointer;
        }

        p {
            text-align: center;
            margin-top: 10px;
        }

        a {
            color: #4CAF50;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Login</h2>
        <form action="login.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
            <br><br>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <br><br>
            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>
