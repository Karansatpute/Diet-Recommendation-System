<?php
// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION["login_success"]) || $_SESSION["login_success"] !== true) {
    // Redirect the user to the login page if not logged in
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Meal</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f5f5f5;
    }

    .header {
      background-color: #333;
      color: #fff;
      padding: 20px;
    }

    .title {
      text-align: center;
      font-size: 1.5em;
    }

    .search-container {
      text-align: center;
      margin-top: 20px;
    }

    .search-input {
      padding: 15px;
      width: 60%;
      font-size: 1.2em;
      border: 1px solid #ddd;
      border-radius: 5px;
      margin-right: 10px;
      outline: none;
    }

    .search-button {
      padding: 12px 20px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s, transform 0.3s;
      font-size: 1em;
      text-transform: uppercase;
      text-shadow: 0 1px 0 rgba(0, 0, 0, 0.1);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
      transform-style: preserve-3d;
    }

    .search-button:hover {
      background-color: #45a049;
      transform: translateY(-2px);
    }

    .list-container {
      display: none;
      position: relative;
      margin-top: 10px;
      max-height: 200px;
      overflow-y: auto;
      transition: max-height 0.3s ease-out;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 5px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      width: 60%;
      margin: auto;
      margin-left: 16%;
    }

    .list-item {
      padding: 10px;
      cursor: pointer;
      transition: background-color 0.3s;
      width: calc(100% - 22px);
      box-sizing: border-box;
    }

    .list-item:hover {
      background-color: #ed8080;
    }

    /* CSS styles for nutrition table */
    .nutrition-table {
      margin: 20px auto;
      width: 80%;
      border-collapse: collapse;
      border: 1px solid #ddd;
      border-radius: 5px;
      overflow: hidden;
      background-color: #f9f9f9; /* Light gray background */
    }

    .nutrition-table th, .nutrition-table td {
      padding: 10px;
      border: 1px solid #ddd;
      text-align: center;
      font-family: Arial, sans-serif; /* Match the font */
      color: #333; /* Match the text color */
    }

    .nutrition-table th {
      border-color: #4CAF50; /* Green border color for column headings */
      background-color: #4CAF50; /* Green background */
      color: #fff; /* White text color */
    }

    /* Specific column heading colors */
    .nutrition-table th:nth-child(1) {
      background-color: #708090;
      color: #fff; 
    }

    .nutrition-table th:nth-child(2) {
      background-color: #4682b4; 
      color: #fff; 
    }

    .nutrition-table th:nth-child(3) {
      background-color: #708090; 
      color: #fff;
    }

    .nutrition-table th:nth-child(4) {
      background-color: #4682b4; 
      color: #fff; 
    }

    .nutrition-table th:nth-child(5) {
      background-color: #708090; 
      color: #fff;
    }

    .nutrition-table th:nth-child(6) {
      background-color: #4682b4; 
      color: #fff; 
    }

    .nutrition-table th:nth-child(7) {
      background-color: #b5dea4; /* Steel Blue for the fourth column */
      color: #333; /* Dark text color */
    }

    .remove-button {
      padding: 8px 12px;
      background-color: #ff6347;
      color: white;
      border: none;
      border-radius: 18px;
      cursor: pointer;
      transition: background-color 0.3s, transform 0.3s;
      font-size: 0.9em;
    }

    .remove-button:hover {
      background-color: #f0837d;
      transform: translateY(-2px);
    }

        /* CSS styles for total nutrition table */
        .total-nutrition-table {
      margin: 20px auto;
      width: 80%;
      border-collapse: collapse;
      border: 1px solid #ddd;
      border-radius: 5px;
      overflow: hidden;
      background-color: #f5f5f5; /* Light gray background */
    }

    .total-nutrition-table th, .total-nutrition-table td {
      padding: 10px;
      border: 1px solid #ddd;
      text-align: center;
      font-family: Arial, sans-serif; /* Match the font */
      color: #333; /* Match the text color */
    }

    .total-nutrition-table th {
      background-color: #4CAF50; /* Green background */
      color: #fff; /* White text color */
    }

    .total-nutrition-table tbody tr:nth-child(even) {
      background-color: #f2f2f2; /* Alternate row background color */
    }

    /* Button styling */


    .button {
      padding: 12px 20px;
      background-color: #f01d1d;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 1em;
      transition: background-color 0.3s, transform 0.3s;
    }

    .button:hover {
      background-color: #fa0505;
      transform: translateY(-2px);
    }

    .username-container {
      position: fixed;
      top: 20px;
      left: 20px;
      font-size: 18px;
      font-weight: bold;
      color: #333;
      background-color: #ded9d9;
      padding: 10px 20px;
      border-radius: 30px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      z-index: 999; /* Ensure it's above other elements */
    }
  </style>
</head>
<body>
<header class="header">
  <h1 class="title">Add Ingredients</h1>
</header>

<div class="search-container">
  <input type="text" class="search-input" placeholder="Search here..." onclick="toggleList()">
  <button class="search-button" onclick="toggleList()">Search</button>
</div>
      <div class="list-container" id="listContainer">
      <div class="list-item" onclick="addFoodItem('Apple')">Apple</div>
      <div class="list-item" onclick="addFoodItem('Apricot')">Apricot</div>
      <div class="list-item" onclick="addFoodItem('Avocado')">Avocado</div>
      <div class="list-item" onclick="addFoodItem('Banana')">Banana</div>
      <div class="list-item" onclick="addFoodItem('Black Chokeberry')">Black Chokeberry</div>
      <div class="list-item" onclick="addFoodItem('Blackberries')">Blackberries</div>
      <div class="list-item" onclick="addFoodItem('Blueberries')">Blueberries</div>
      <div class="list-item" onclick="addFoodItem('Cantaloupe')">Cantaloupe</div>
      <div class="list-item" onclick="addFoodItem('Cherry')">Cherry</div>
      <div class="list-item" onclick="addFoodItem('Cranberry')">Cranberry</div>
      <div class="list-item" onclick="addFoodItem('Date Palm')">Date Palm</div>
      <div class="list-item" onclick="addFoodItem('Durian')">Durian</div>
      <div class="list-item" onclick="addFoodItem('Elderberry')">Elderberry</div>
      <div class="list-item" onclick="addFoodItem('Golden berries')">Golden berries</div>
      <div class="list-item" onclick="addFoodItem('Gooseberries')">Gooseberries</div>
      <div class="list-item" onclick="addFoodItem('Grapefruit')">Grapefruit</div>
      <div class="list-item" onclick="addFoodItem('Grapes')">Grapes</div>
      <div class="list-item" onclick="addFoodItem('Guava')">Guava</div>
      <div class="list-item" onclick="addFoodItem('Jackfruit')">Jackfruit</div>
      <div class="list-item" onclick="addFoodItem('Jujube')">Jujube</div>
      <div class="list-item" onclick="addFoodItem('Juniper Berries')">Juniper Berries</div>
      <div class="list-item" onclick="addFoodItem('Kiwi')">Kiwi</div>
      <div class="list-item" onclick="addFoodItem('Longan Fruit')">Longan Fruit</div>
      <div class="list-item" onclick="addFoodItem('Lychee')">Lychee</div>
      <div class="list-item" onclick="addFoodItem('Mango')">Mango</div>
      <div class="list-item" onclick="addFoodItem('Melon')">Melon</div>
      <div class="list-item" onclick="addFoodItem('Mulberry')">Mulberry</div>
      <div class="list-item" onclick="addFoodItem('Nectarines')">Nectarines</div>
      <div class="list-item" onclick="addFoodItem('Orange')">Orange</div>
      <div class="list-item" onclick="addFoodItem('Papaya')">Papaya</div>
      <div class="list-item" onclick="addFoodItem('Passion Fruit')">Passion Fruit</div>
      <div class="list-item" onclick="addFoodItem('Pear')">Pear</div>
      <div class="list-item" onclick="addFoodItem('Persimmon')">Persimmon</div>
      <div class="list-item" onclick="addFoodItem('Pineapple')">Pineapple</div>
      <div class="list-item" onclick="addFoodItem('Plum')">Plum</div>
      <div class="list-item" onclick="addFoodItem('Pomegranate')">Pomegranate</div>
      <div class="list-item" onclick="addFoodItem('Pomelo')">Pomelo</div>
      <div class="list-item" onclick="addFoodItem('Rambutan')">Rambutan</div>
      <div class="list-item" onclick="addFoodItem('Raspberry')">Raspberry</div>
      <div class="list-item" onclick="addFoodItem('Redberries')">Redberries</div>
      <div class="list-item" onclick="addFoodItem('Rhubarb')">Rhubarb</div>
      <div class="list-item" onclick="addFoodItem('Starfruit')">Starfruit</div>
      <div class="list-item" onclick="addFoodItem('Strawberry')">Strawberry</div>
      <div class="list-item" onclick="addFoodItem('Tangerine')">Tangerine</div>
      <div class="list-item" onclick="addFoodItem('Uglifruit')">Uglifruit</div>
      <div class="list-item" onclick="addFoodItem('Watermelon')">Watermelon</div>
      <div class="list-item" onclick="addFoodItem('Harrd Red Wheat')">Harrd Red Wheat</div>
      <div class="list-item" onclick="addFoodItem('Soft Red Wheat')">Soft Red Wheat</div>
      <div class="list-item" onclick="addFoodItem('Hard White Wheat')">Hard White Wheat</div>
      <div class="list-item" onclick="addFoodItem('Soft White Wheat')">Soft White Wheat</div>
      <div class="list-item" onclick="addFoodItem('Durum Wheat')">Durum Wheat</div>
      <div class="list-item" onclick="addFoodItem('Einkorn Wheat')">Einkorn Wheat</div>
      <div class="list-item" onclick="addFoodItem('Spelt Wheat')">Spelt Wheat</div>
      <div class="list-item" onclick="addFoodItem('Emmer Wheat')">Emmer Wheat</div>
      <div class="list-item" onclick="addFoodItem('White Rice')">White Rice</div>
      <div class="list-item" onclick="addFoodItem('Brown Rice')">Brown Rice</div>
      <div class="list-item" onclick="addFoodItem('Basmati Rice')">Basmati Rice</div>
      <div class="list-item" onclick="addFoodItem('Jasmine Rice')">Jasmine Rice</div>
      <div class="list-item" onclick="addFoodItem('Arborio Rice')">Arborio Rice</div>
      <div class="list-item" onclick="addFoodItem('Black Rice')">Black Rice</div>
      <div class="list-item" onclick="addFoodItem('Red Rice')">Red Rice</div>
      <div class="list-item" onclick="addFoodItem('Wild RIce')">Wild RIce</div>
      <div class="list-item" onclick="addFoodItem('Dent Corn')">Dent Corn</div>
      <div class="list-item" onclick="addFoodItem('Sweet Corn')">Sweet Corn</div>
      <div class="list-item" onclick="addFoodItem('Popcorn')">Popcorn</div>
      <div class="list-item" onclick="addFoodItem('Flint Corn')">Flint Corn</div>
      <div class="list-item" onclick="addFoodItem('Flour Corn')">Flour Corn</div>
      <div class="list-item" onclick="addFoodItem('Waxy Corn')">Waxy Corn</div>
      <div class="list-item" onclick="addFoodItem('Rolled Oats')">Rolled Oats</div>
      <div class="list-item" onclick="addFoodItem('Steel-cut Oats')">Steel-cut Oats</div>
      <div class="list-item" onclick="addFoodItem('Quick Oats')">Quick Oats</div>
      <div class="list-item" onclick="addFoodItem('Instant Oats')">Instant Oats</div>
      <div class="list-item" onclick="addFoodItem('Oat Groats')">Oat Groats</div>
      <div class="list-item" onclick="addFoodItem('Hulled Barley')">Hulled Barley</div>
      <div class="list-item" onclick="addFoodItem('Pearled Barley')">Pearled Barley</div>
      <div class="list-item" onclick="addFoodItem('Scotch Barley')">Scotch Barley</div>
      <div class="list-item" onclick="addFoodItem('Barley Flakes')">Barley Flakes</div>
      <div class="list-item" onclick="addFoodItem('Barley Grits')">Barley Grits</div>
      <div class="list-item" onclick="addFoodItem('Barley Flour')">Barley Flour</div>
      <div class="list-item" onclick="addFoodItem('Purple Barley')">Purple Barley</div>
      <div class="list-item" onclick="addFoodItem('Black Barley')">Black Barley</div>
      <div class="list-item" onclick="addFoodItem('Sprouted Barley')">Sprouted Barley</div>
      <div class="list-item" onclick="addFoodItem('Whole Rye')">Whole Rye</div>
      <div class="list-item" onclick="addFoodItem('Rye Flakes')">Rye Flakes</div>
      <div class="list-item" onclick="addFoodItem('Rye Flour')">Rye Flour</div>
      <div class="list-item" onclick="addFoodItem('Pumpernickel')">Pumpernickel</div>
      <div class="list-item" onclick="addFoodItem('Rye Bread')">Rye Bread</div>
      <div class="list-item" onclick="addFoodItem('White Quinoa')">White Quinoa</div>
      <div class="list-item" onclick="addFoodItem('Red Quinoa')">Red Quinoa</div>
      <div class="list-item" onclick="addFoodItem('Black Quinoa')">Black Quinoa</div>
      <div class="list-item" onclick="addFoodItem('Tri-color Quinoa')">Tri-color Quinoa</div>
      <div class="list-item" onclick="addFoodItem('Purple Quinoa')">Purple Quinoa</div>
      <div class="list-item" onclick="addFoodItem('High-altitude Quinoa')">High-altitude Quinoa</div>
      <div class="list-item" onclick="addFoodItem('Golden Quinoa')">Golden Quinoa</div>
      <div class="list-item" onclick="addFoodItem('Pearl Millet')">Pearl Millet</div>
      <div class="list-item" onclick="addFoodItem('Foxtail Millet')">Foxtail Millet</div>
      <div class="list-item" onclick="addFoodItem('Finger Millet')">Finger Millet</div>
      <div class="list-item" onclick="addFoodItem('Proso Millet')">Proso Millet</div>
      <div class="list-item" onclick="addFoodItem('Barnyard Millet')">Barnyard Millet</div>
      <div class="list-item" onclick="addFoodItem('Kodo Millet')">Kodo Millet</div>
      <div class="list-item" onclick="addFoodItem('Little Millet')">Little Millet</div>
      <div class="list-item" onclick="addFoodItem('Grain Sorghum')">Grain Sorghum</div>
      <div class="list-item" onclick="addFoodItem('Sweet Sorghum')">Sweet Sorghum</div>
      <div class="list-item" onclick="addFoodItem('Broomcorn Sorghum')">Broomcorn Sorghum</div>
      <div class="list-item" onclick="addFoodItem('Black Sorghum')">Black Sorghum</div>
      <div class="list-item" onclick="addFoodItem('White Sorghum')">White Sorghum</div>
      <div class="list-item" onclick="addFoodItem('Red Sorghum')">Red Sorghum</div>
      <div class="list-item" onclick="addFoodItem('Common Buckwheat')">Common Buckwheat</div>
      <div class="list-item" onclick="addFoodItem('Tartary Buckwheat')">Tartary Buckwheat</div>
      <div class="list-item" onclick="addFoodItem('Silverhull Buckwheat')">Silverhull Buckwheat</div>
      <div class="list-item" onclick="addFoodItem('Buckwheat Groats')">Buckwheat Groats</div>
      <div class="list-item" onclick="addFoodItem('Kasha')">Kasha</div>
      <div class="list-item" onclick="addFoodItem('Amaranth (Ramdana)')">Amaranth (Ramdana)</div>
      <div class="list-item" onclick="addFoodItem('Ivory Teff')">Ivory Teff</div>
      <div class="list-item" onclick="addFoodItem('Brown Teff')">Brown Teff</div>
      <div class="list-item" onclick="addFoodItem('Mixed Teff')">Mixed Teff</div>
      <div class="list-item" onclick="addFoodItem('Spelt')">Spelt</div>
      <div class="list-item" onclick="addFoodItem('Kamut')">Kamut</div>
      <div class="list-item" onclick="addFoodItem('Emmer Farro')">Emmer Farro</div>
      <div class="list-item" onclick="addFoodItem('Spelt Farro')">Spelt Farro</div>
      <div class="list-item" onclick="addFoodItem('Bulgur( Dalia)')">Bulgur( Dalia)</div>
      <div class="list-item" onclick="addFoodItem('Hot Chocolate')">Hot Chocolate</div>
      <div class="list-item" onclick="addFoodItem('Mulled Wine')">Mulled Wine</div>
      <div class="list-item" onclick="addFoodItem('Affogato')">Affogato</div>
      <div class="list-item" onclick="addFoodItem('Bone broth')">Bone broth</div>
      <div class="list-item" onclick="addFoodItem('Yerba mate')">Yerba mate</div>
      <div class="list-item" onclick="addFoodItem('Gluhwein')">Gluhwein</div>
      <div class="list-item" onclick="addFoodItem('Bissap')">Bissap</div>
      <div class="list-item" onclick="addFoodItem('Horchata')">Horchata</div>
      <div class="list-item" onclick="addFoodItem('Spiced cider')">Spiced cider</div>
      <div class="list-item" onclick="addFoodItem('White hot chocolate')">White hot chocolate</div>
      <div class="list-item" onclick="addFoodItem('Coconut hot chocolate')">Coconut hot chocolate</div>
      <div class="list-item" onclick="addFoodItem('Peanut butter hot chocolate')">Peanut butter hot chocolate</div>
      <div class="list-item" onclick="addFoodItem('Mint hot chocolate')">Mint hot chocolate</div>
      <div class="list-item" onclick="addFoodItem('Iced Tea')">Iced Tea</div>
      <div class="list-item" onclick="addFoodItem('Lemonade')">Lemonade</div>
      <div class="list-item" onclick="addFoodItem('Smoothies')">Smoothies</div>
      <div class="list-item" onclick="addFoodItem('Milkshakes')">Milkshakes</div>
      <div class="list-item" onclick="addFoodItem('Slushies')">Slushies</div>
      <div class="list-item" onclick="addFoodItem('Kombucha')">Kombucha</div>
      <div class="list-item" onclick="addFoodItem('Iced Coffee')">Iced Coffee</div>
      <div class="list-item" onclick="addFoodItem('Frappuccino')">Frappuccino</div>
      <div class="list-item" onclick="addFoodItem('Soda')">Soda</div>
      <div class="list-item" onclick="addFoodItem('Sparkling Water')">Sparkling Water</div>
      <div class="list-item" onclick="addFoodItem('Flavored Water')">Flavored Water</div>
      <div class="list-item" onclick="addFoodItem('Coconut Water')">Coconut Water</div>
      <div class="list-item" onclick="addFoodItem('Sports Drinks')">Sports Drinks</div>
      <div class="list-item" onclick="addFoodItem('Energy Drinks')">Energy Drinks</div>
      <div class="list-item" onclick="addFoodItem('Protien Shakes')">Protien Shakes</div>
      <div class="list-item" onclick="addFoodItem('Chai Latte(iced)')">Chai Latte(iced)</div>
      <div class="list-item" onclick="addFoodItem('Arnold Palmer')">Arnold Palmer</div>
      <div class="list-item" onclick="addFoodItem('Italian Soda')">Italian Soda</div>
      <div class="list-item" onclick="addFoodItem('Agua Fresca')">Agua Fresca</div>
      <div class="list-item" onclick="addFoodItem('Green Smoothies')">Green Smoothies</div>
      <div class="list-item" onclick="addFoodItem('Mango Lassi')">Mango Lassi</div>
      <div class="list-item" onclick="addFoodItem('Cucumber Water')">Cucumber Water</div>
      <div class="list-item" onclick="addFoodItem('Fruit infused Iced Tea')">Fruit infused Iced Tea</div>
      <div class="list-item" onclick="addFoodItem('Thai Iced tea')">Thai Iced tea</div>
      <div class="list-item" onclick="addFoodItem('Matcha Latte (iced)')">Matcha Latte (iced)</div>
      <div class="list-item" onclick="addFoodItem('Peppermint Iced Tea')">Peppermint Iced Tea</div>
      <div class="list-item" onclick="addFoodItem('Peach iced Tea')">Peach iced Tea</div>
      <div class="list-item" onclick="addFoodItem('Ginger Beer')">Ginger Beer</div>
      <div class="list-item" onclick="addFoodItem('Limeade')">Limeade</div>
      <div class="list-item" onclick="addFoodItem('Blueberry Smoothie')">Blueberry Smoothie</div>
      <div class="list-item" onclick="addFoodItem('Vanilla Milkshake')">Vanilla Milkshake</div>
      <div class="list-item" onclick="addFoodItem('Chocolate Milkshake')">Chocolate Milkshake</div>
      <div class="list-item" onclick="addFoodItem('Almond Milkshake')">Almond Milkshake</div>
      <div class="list-item" onclick="addFoodItem('Cashew Milkshake')">Cashew Milkshake</div>
      <div class="list-item" onclick="addFoodItem('Rose Water Lemonade')">Rose Water Lemonade</div>
      <div class="list-item" onclick="addFoodItem('Mint Lemonande')">Mint Lemonande</div>
      <div class="list-item" onclick="addFoodItem('Black Iced Tea')">Black Iced Tea</div>
      <div class="list-item" onclick="addFoodItem('White Iced Tea')">White Iced Tea</div>
      <div class="list-item" onclick="addFoodItem('Rooibos Iced tea')">Rooibos Iced tea</div>
      <div class="list-item" onclick="addFoodItem('Broccoli')">Broccoli</div>
      <div class="list-item" onclick="addFoodItem('Carrots')">Carrots</div>
      <div class="list-item" onclick="addFoodItem('Spinach')">Spinach</div>
      <div class="list-item" onclick="addFoodItem('Sweet Potato')">Sweet Potato</div>
      <div class="list-item" onclick="addFoodItem('Tomatoes')">Tomatoes</div>
      <div class="list-item" onclick="addFoodItem('Beetroot')">Beetroot</div>
      <div class="list-item" onclick="addFoodItem('Cabbage')">Cabbage</div>
      <div class="list-item" onclick="addFoodItem('Cauliflower')">Cauliflower</div>
      <div class="list-item" onclick="addFoodItem('Celery')">Celery</div>
      <div class="list-item" onclick="addFoodItem('Cucumber')">Cucumber</div>
      <div class="list-item" onclick="addFoodItem('Garlic')">Garlic</div>
      <div class="list-item" onclick="addFoodItem('Lettuce')">Lettuce</div>
      <div class="list-item" onclick="addFoodItem('Mushroom')">Mushroom</div>
      <div class="list-item" onclick="addFoodItem('Onion')">Onion</div>
      <div class="list-item" onclick="addFoodItem('Peas')">Peas</div>
      <div class="list-item" onclick="addFoodItem('Green Pepper')">Green Pepper</div>
      <div class="list-item" onclick="addFoodItem('Yellow Pepper')">Yellow Pepper</div>
      <div class="list-item" onclick="addFoodItem('Red Pepper')">Red Pepper</div>
      <div class="list-item" onclick="addFoodItem('Potato')">Potato</div>
      <div class="list-item" onclick="addFoodItem('Pumpkin')">Pumpkin</div>
      <div class="list-item" onclick="addFoodItem('Radish')">Radish</div>
      <div class="list-item" onclick="addFoodItem('Zucchini')">Zucchini</div>
      <div class="list-item" onclick="addFoodItem('Water Chestnut')">Water Chestnut</div>
      <div class="list-item" onclick="addFoodItem('Turnips')">Turnips</div>
      <div class="list-item" onclick="addFoodItem('Yellow Onion')">Yellow Onion</div>
      <div class="list-item" onclick="addFoodItem('Green Onion')">Green Onion</div>
      <div class="list-item" onclick="addFoodItem('Eggplant')">Eggplant</div>
      <div class="list-item" onclick="addFoodItem('Dandelion Greens')">Dandelion Greens</div>
      <div class="list-item" onclick="addFoodItem('Artichokes')">Artichokes</div>
      <div class="list-item" onclick="addFoodItem('Asparagus')">Asparagus</div>
      <div class="list-item" onclick="addFoodItem('Arugula')">Arugula</div>
      <div class="list-item" onclick="addFoodItem('Aubergine')">Aubergine</div>
      <div class="list-item" onclick="addFoodItem('Bamboo Shoots')">Bamboo Shoots</div>
      <div class="list-item" onclick="addFoodItem('Brussels Sprouts')">Brussels Sprouts</div>
      <div class="list-item" onclick="addFoodItem('Cilantro')">Cilantro</div>
      <div class="list-item" onclick="addFoodItem('Dill')">Dill</div>
      <div class="list-item" onclick="addFoodItem('Fennel')">Fennel</div>
      <div class="list-item" onclick="addFoodItem('Kale')">Kale</div>
      <div class="list-item" onclick="addFoodItem('Leek')">Leek</div>
      <div class="list-item" onclick="addFoodItem('Romaine Lettuce')">Romaine Lettuce</div>
      <div class="list-item" onclick="addFoodItem('Japanese Mustard Greens')">Japanese Mustard Greens</div>
      <div class="list-item" onclick="addFoodItem('Okra')">Okra</div>
      <div class="list-item" onclick="addFoodItem('Parsley')">Parsley</div>
      <div class="list-item" onclick="addFoodItem('Soybeans')">Soybeans</div>
      <div class="list-item" onclick="addFoodItem('Snow Peas')">Snow Peas</div>
      <div class="list-item" onclick="addFoodItem('Squash')">Squash</div>
      <div class="list-item" onclick="addFoodItem('Swiss Chard')">Swiss Chard</div>
      <div class="list-item" onclick="addFoodItem('Thyme')">Thyme</div>
      <div class="list-item" onclick="addFoodItem('Watercress')">Watercress</div>
      <div class="list-item" onclick="addFoodItem('Kohlrabi')">Kohlrabi</div>
      <div class="list-item" onclick="addFoodItem('Bok Choy')">Bok Choy</div>
      <div class="list-item" onclick="addFoodItem('Chicory')">Chicory</div>
      <div class="list-item" onclick="addFoodItem('Endive')">Endive</div>
      <div class="list-item" onclick="addFoodItem('Heart of Palm')">Heart of Palm</div>
      <div class="list-item" onclick="addFoodItem('Jalapeno Peppers')">Jalapeno Peppers</div>
      <div class="list-item" onclick="addFoodItem('Cayenne Pepper')">Cayenne Pepper</div>
      <div class="list-item" onclick="addFoodItem('Chili Pepper')">Chili Pepper</div>
      <div class="list-item" onclick="addFoodItem('Poblano Pepper')">Poblano Pepper</div>
      <div class="list-item" onclick="addFoodItem('Serrano Pepper')">Serrano Pepper</div>
      <div class="list-item" onclick="addFoodItem('Anaheim Pepper')">Anaheim Pepper</div>
      <div class="list-item" onclick="addFoodItem('Bell Peppers')">Bell Peppers</div>
      <div class="list-item" onclick="addFoodItem('Pimento')">Pimento</div>
      <div class="list-item" onclick="addFoodItem('Tabasco Pepper')">Tabasco Pepper</div>
      <div class="list-item" onclick="addFoodItem('Thai Chili Pepper')">Thai Chili Pepper</div>
      <div class="list-item" onclick="addFoodItem('Cilantro')">Cilantro</div>
      <div class="list-item" onclick="addFoodItem('Parsley')">Parsley</div>
      <div class="list-item" onclick="addFoodItem('Basil')">Basil</div>
      <div class="list-item" onclick="addFoodItem('Oregano')">Oregano</div>
      <div class="list-item" onclick="addFoodItem('Mint')">Mint</div>
      <div class="list-item" onclick="addFoodItem('Rosemary')">Rosemary</div>
      <div class="list-item" onclick="addFoodItem('Thyme')">Thyme</div>
      <div class="list-item" onclick="addFoodItem('Sage')">Sage</div>
      <div class="list-item" onclick="addFoodItem('Dill')">Dill</div>
      <div class="list-item" onclick="addFoodItem('Tarragon')">Tarragon</div>
      <div class="list-item" onclick="addFoodItem('Cinnamon')">Cinnamon</div>
      <div class="list-item" onclick="addFoodItem('Nutmeg')">Nutmeg</div>
      <div class="list-item" onclick="addFoodItem('Cardamom')">Cardamom</div>
      <div class="list-item" onclick="addFoodItem('Allspice')">Allspice</div>
      <div class="list-item" onclick="addFoodItem('Ginger')">Ginger</div>
      <div class="list-item" onclick="addFoodItem('Turmeric')">Turmeric</div>
      <div class="list-item" onclick="addFoodItem('Coriander')">Coriander</div>
      <div class="list-item" onclick="addFoodItem('Cumin')">Cumin</div>
      <div class="list-item" onclick="addFoodItem('Fenugreek')">Fenugreek</div>
      <div class="list-item" onclick="addFoodItem('White Pepper')">White Pepper</div>
      <div class="list-item" onclick="addFoodItem('Saffron')">Saffron</div>
      <div class="list-item" onclick="addFoodItem('Vanilla')">Vanilla</div>
      <div class="list-item" onclick="addFoodItem('Mustard Seeds')">Mustard Seeds</div>
      <div class="list-item" onclick="addFoodItem('Fennel Seeds')">Fennel Seeds</div>
      <div class="list-item" onclick="addFoodItem('Paprika')">Paprika</div>
      <div class="list-item" onclick="addFoodItem('Chili Powder')">Chili Powder</div>
      <div class="list-item" onclick="addFoodItem('Cayenne Pepper')">Cayenne Pepper</div>
      <div class="list-item" onclick="addFoodItem('Smoked Paprika')">Smoked Paprika</div>
      <div class="list-item" onclick="addFoodItem('Garlic Powder')">Garlic Powder</div>
      <div class="list-item" onclick="addFoodItem('Onion Powder')">Onion Powder</div>
      <div class="list-item" onclick="addFoodItem('Celery Salt')">Celery Salt</div>
      <div class="list-item" onclick="addFoodItem('Cumin Powder')">Cumin Powder</div>
      <div class="list-item" onclick="addFoodItem('Taco Seasoning')">Taco Seasoning</div>
      <div class="list-item" onclick="addFoodItem('Garam Masala')">Garam Masala</div>
      <div class="list-item" onclick="addFoodItem('Curry Powder')">Curry Powder</div>
      <div class="list-item" onclick="addFoodItem('Poultry Seasoning')">Poultry Seasoning</div>
      <div class="list-item" onclick="addFoodItem('Chinese 5 Spice')">Chinese 5 Spice</div>
      <div class="list-item" onclick="addFoodItem('Szechuan Peppercorns')">Szechuan Peppercorns</div>
      <div class="list-item" onclick="addFoodItem('Nutmeg')">Nutmeg</div>
      <div class="list-item" onclick="addFoodItem('Allspice')">Allspice</div>
      <div class="list-item" onclick="addFoodItem('Pumpkin Pie Spice')">Pumpkin Pie Spice</div>
      <div class="list-item" onclick="addFoodItem('Adobo')">Adobo</div>
      <div class="list-item" onclick="addFoodItem('Ras el Hanout')">Ras el Hanout</div>
      <div class="list-item" onclick="addFoodItem('Harissa')">Harissa</div>
      <div class="list-item" onclick="addFoodItem('Dukkah')">Dukkah</div>
      <div class="list-item" onclick="addFoodItem('Berbere')">Berbere</div>
      <div class="list-item" onclick="addFoodItem('Za’atar')">Za’atar</div>
      <div class="list-item" onclick="addFoodItem('Shichimi Togarashi')">Shichimi Togarashi</div>
      <div class="list-item" onclick="addFoodItem('Gochugaru')">Gochugaru</div>
      <div class="list-item" onclick="addFoodItem('Furikake')">Furikake</div>
      <div class="list-item" onclick="addFoodItem('Chaat Masala')">Chaat Masala</div>
      <div class="list-item" onclick="addFoodItem('Lemon Zest')">Lemon Zest</div>
      <div class="list-item" onclick="addFoodItem('Orange Zest')">Orange Zest</div>
      <div class="list-item" onclick="addFoodItem('Lemon Extract')">Lemon Extract</div>
      <div class="list-item" onclick="addFoodItem('Orange Extract')">Orange Extract</div>
      <div class="list-item" onclick="addFoodItem('Vanilla Extract')">Vanilla Extract</div>
      <div class="list-item" onclick="addFoodItem('Peppermint Extract')">Peppermint Extract</div>
      <div class="list-item" onclick="addFoodItem('Almond Extract')">Almond Extract</div>
      <div class="list-item" onclick="addFoodItem('Chocolate Extract')">Chocolate Extract</div>
      <div class="list-item" onclick="addFoodItem('Maple Extract')">Maple Extract</div>
      <div class="list-item" onclick="addFoodItem('Coconut Extract')">Coconut Extract</div>
      <div class="list-item" onclick="addFoodItem('Butter Extract')">Butter Extract</div>
      <div class="list-item" onclick="addFoodItem('Peppermint Oil')">Peppermint Oil</div>
      <div class="list-item" onclick="addFoodItem('Lemon Oil')">Lemon Oil</div>
      <div class="list-item" onclick="addFoodItem('Orange Oil')">Orange Oil</div>
      <div class="list-item" onclick="addFoodItem('Vanilla Paste')">Vanilla Paste</div>
      <div class="list-item" onclick="addFoodItem('Rose Water')">Rose Water</div>
      <div class="list-item" onclick="addFoodItem('Maple Syrup')">Maple Syrup</div>
      <div class="list-item" onclick="addFoodItem('Honey')">Honey</div>

</div>

<table class="nutrition-table" id="nutritionTable">
  <thead>
    <tr>
      <th>Ingredients</th>
      <th>Weight</th>
      <th>Calories (kcal)</th>
      <th>Protein (g)</th>
      <th>Carbs (g)</th>
      <th>Fats (g)</th>
      <th>-------------</th>
    </tr>
  </thead>
  <tbody>
    <!-- Table rows will be dynamically added here -->
  </tbody>
</table>
  
<table class="total-nutrition-table">
    <thead>
      <tr>
        <th>Total Calories (kcal)</th>
        <th>Total Protein (g)</th>
        <th>Total Carbs (g)</th>
        <th>Total Fats (g)</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td id="totalCalories">0</td>
        <td id="totalProtein">0</td>
        <td id="totalCarbs">0</td>
        <td id="totalFats">0</td>
      </tr>
    </tbody>
  </table>

<script>
    // Define an array to store selected items
    var selectedItems = [];

    // Function to toggle the visibility of the dropdown list
    function toggleList() {
        var listContainer = document.getElementById("listContainer");
        listContainer.style.display = listContainer.style.display === "none" ? "block" : "none";
    }

    // Function to add a food item to the table
    function addFoodItem(item) {
        // Check if the item is already selected
        if (selectedItems.includes(item)) {
            alert("This item is already selected.");
            return; // Exit the function if the item is already selected
        }

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'fetch_data.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
            console.log(xhr.responseText); // Log the response
            var data = JSON.parse(xhr.responseText); // Try parsing the response
            console.log(data); // Log the parsed data
            updateTable(item, data);
        } else {
            alert('Error: ' + xhr.status);
        }
    }
};

        xhr.send('food_items=' + encodeURIComponent(item));

        // Add the item to the selected items array
        selectedItems.push(item);
    }
    // Function to update the total nutrition values
function updateTotalNutrition() {
    var totalCalories = 0;
    var totalProtein = 0;
    var totalCarbs = 0;
    var totalFats = 0;

    var tableRows = document.querySelectorAll(".nutrition-table tbody tr");

    tableRows.forEach(function(row) {
        totalCalories += parseFloat(row.children[2].textContent);
        totalProtein += parseFloat(row.children[3].textContent);
        totalCarbs += parseFloat(row.children[4].textContent);
        totalFats += parseFloat(row.children[5].textContent);
    });

    // Format the totals with the same precision as the individual values
    var precision = 3; // Adjust as needed
    totalCalories = totalCalories.toFixed(precision);
    totalProtein = totalProtein.toFixed(precision);
    totalCarbs = totalCarbs.toFixed(precision);
    totalFats = totalFats.toFixed(precision);

    document.getElementById("totalCalories").textContent = totalCalories;
    document.getElementById("totalProtein").textContent = totalProtein;
    document.getElementById("totalCarbs").textContent = totalCarbs;
    document.getElementById("totalFats").textContent = totalFats;
}

    // Function to update the table with the selected item
    function updateTable(item, data) {
        console.log("Received data:", data); // Log the received data
        var tableBody = document.querySelector(".nutrition-table tbody");
        var newRow = document.createElement("tr");
        newRow.innerHTML = `
            <td>${item}</td>
            <td>${data['Weight']}</td> 
            <td>${data['Calories']}</td>
            <td>${data['Protein']}</td>
            <td>${data['Carbs']}</td>
            <td>${data['Fats']}</td>
            <td><button class="remove-button" onclick="removeFoodItem(this)">Remove</button></td>
        `;
        tableBody.appendChild(newRow);

        // Update total nutrition values
        updateTotalNutrition();
    }

    // Function to remove a food item from the table
    function removeFoodItem(button) {
        var row = button.parentNode.parentNode;
        var itemName = row.querySelector("td:first-child").innerText;
        // Remove the item from the selected items array
        selectedItems = selectedItems.filter(item => item !== itemName);
        // Remove the row from the table
        row.parentNode.removeChild(row);

        // Update total nutrition values
        updateTotalNutrition();
    }
    // Function to filter items based on search query
function filterItems(query) {
    var listItems = document.querySelectorAll('.list-item');
    var searchTerm = query.toLowerCase();

    listItems.forEach(function(item) {
        var itemName = item.textContent.toLowerCase();
        if (itemName.includes(searchTerm)) {
            item.style.display = 'block'; // Show matching items
        } else {
            item.style.display = 'none'; // Hide non-matching items
        }
    });

    // Show or hide the list container based on whether there are matching items
    var listContainer = document.getElementById("listContainer");
    var visibleItems = Array.from(listItems).filter(item => item.style.display !== 'none');
    listContainer.style.display = visibleItems.length > 0 ? 'block' : 'none';
}

// Add input event listener to the search input field
var searchInput = document.querySelector('.search-input');
searchInput.addEventListener('input', function(event) {
    var query = event.target.value.trim();
    filterItems(query);
});



// Function to generate PDF
function generatePDF() {
    console.log("Button clicked!"); // Check if the button click event is registered
    const doc = new jsPDF();

    // Get HTML content to be converted to PDF
    const content = document.documentElement;

    // Convert HTML to PDF
    doc.html(content, {
      callback: function(pdf) {
        // Save the PDF
        pdf.save("meal_plan.pdf");
      }
    });
  }

  // Add event listener to the download button
  const downloadButton = document.getElementById("downloadButton");
  downloadButton.addEventListener("click", generatePDF);
</script>
</body>
</html>