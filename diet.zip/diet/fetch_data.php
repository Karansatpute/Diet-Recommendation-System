<?php
if(isset($_POST['food_items'])) {
    $food_item = $_POST['food_items'];

    // Perform a database query to retrieve the data
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "diet";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the query to fetch Weight and Calories
    $stmt = $conn->prepare("SELECT ROUND(`Weight`, 2) AS `Weight`, ROUND(`Calories`, 3) AS `Calories` FROM `calorie_value` WHERE `food items` = ?");
    $stmt->bind_param("s", $food_item); 
    $stmt->execute();
    $result_calorie = $stmt->get_result();

    // Prepare and execute the query to fetch Protein, Carbs, and Fats
    $stmr = $conn->prepare("SELECT ROUND(`Protein`, 6) AS `Protein`, ROUND(`Carbs`, 6) AS `Carbs`, ROUND(`Fats`, 6) AS `Fats` FROM `final_food_items` WHERE `food items` = ?");
    $stmr->bind_param("s", $food_item);
    $stmr->execute();
    $result_nutrition = $stmr->get_result();

    // Check if rows are found for both queries
    if ($result_calorie->num_rows > 0 && $result_nutrition->num_rows > 0) {
        // Fetch the data from both queries
        $row_calorie = $result_calorie->fetch_assoc();
        $row_nutrition = $result_nutrition->fetch_assoc();
        
        // Combine the data from both queries
        $combined_row = array_map('floatval', array_merge($row_calorie, $row_nutrition));
        
        // Close the prepared statement and connection
        $stmt->close();
        $stmr->close();
        $conn->close();
        
        // Return the combined data as JSON
        echo json_encode($combined_row);
    } else {
        // If no row found for any query, return an empty JSON object
        echo json_encode(array());
    }
} 
?>
